# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------
# Copyright 2021 VMware, Inc.  All rights reserved.

# AUTO GENERATED FILE -- DO NOT MODIFY!
#
# vAPI stub file for package com.vmware.appliance.vcenter.settings.v1.config.components.vsphereuiconfiguration.
#---------------------------------------------------------------------------

"""


"""

__author__ = 'VMware, Inc.'
__docformat__ = 'restructuredtext en'

import sys

from vmware.vapi.bindings import type
from vmware.vapi.bindings.converter import TypeConverter
from vmware.vapi.bindings.enum import Enum
from vmware.vapi.bindings.error import VapiError
from vmware.vapi.bindings.struct import VapiStruct
from vmware.vapi.bindings.stub import (
    ApiInterfaceStub, StubFactoryBase, VapiInterface)
from vmware.vapi.bindings.common import raise_core_exception
from vmware.vapi.data.validator import (UnionValidator, HasFieldsOfValidator)
from vmware.vapi.exception import CoreException
from vmware.vapi.lib.constants import TaskType
from vmware.vapi.lib.rest import OperationRestMetadata


class VsphereUIConfiguration(VapiStruct):
    """
    ``VsphereUIConfiguration`` class This spec is used to configure the
    behavior of the vsphere-ui service.

    .. tip::
        The arguments are used to initialize data attributes with the same
        names.
    """



    _canonical_to_pep_names = {
                            'enable_IDP_configuration': 'enable_idp_configuration',
                            }

    def __init__(self,
                 enable_idp_configuration=None,
                 enable_cloud_admin_role_protection=None,
                ):
        """
        :type  enable_idp_configuration: :class:`bool` or ``None``
        :param enable_idp_configuration: Property to configure the IDPConfiguration view, with this enabled,
            user will be able to view and configure IDP
        :type  enable_cloud_admin_role_protection: :class:`bool` or ``None``
        :param enable_cloud_admin_role_protection: Property to enable CloudAdminRoleProtection in the UI
        """
        self.enable_idp_configuration = enable_idp_configuration
        self.enable_cloud_admin_role_protection = enable_cloud_admin_role_protection
        VapiStruct.__init__(self)


VsphereUIConfiguration._set_binding_type(type.StructType(
    'com.vmware.appliance.vcenter.settings.v1.config.components.vsphereuiconfiguration.vsphere_UI_configuration', {
        'enable_IDP_configuration': type.OptionalType(type.BooleanType()),
        'enable_cloud_admin_role_protection': type.OptionalType(type.BooleanType()),
    },
    VsphereUIConfiguration,
    False,
    None))




class StubFactory(StubFactoryBase):
    _attrs = {
    }

