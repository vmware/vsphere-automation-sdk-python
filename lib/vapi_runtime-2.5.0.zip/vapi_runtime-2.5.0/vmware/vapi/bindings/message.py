"""
Message Factory import for the bindings to use
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright (c) 2015 VMware, Inc.  All rights reserved.'

from vmware.vapi.message import MessageFactory  # pylint: disable=W0611
