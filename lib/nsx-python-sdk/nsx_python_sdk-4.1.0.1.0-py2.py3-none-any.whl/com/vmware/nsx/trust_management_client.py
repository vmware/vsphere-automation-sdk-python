# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------
# Copyright 2023 VMware, Inc.  All rights reserved.

# AUTO GENERATED FILE -- DO NOT MODIFY!
#
# vAPI stub file for package com.vmware.nsx.trust_management.
#---------------------------------------------------------------------------

"""


"""

__author__ = 'VMware, Inc.'
__docformat__ = 'restructuredtext en'

import sys
from warnings import warn

from vmware.vapi.bindings import type
from vmware.vapi.bindings.converter import TypeConverter
from vmware.vapi.bindings.enum import Enum
from vmware.vapi.bindings.error import VapiError
from vmware.vapi.bindings.struct import VapiStruct
from vmware.vapi.bindings.stub import (
    ApiInterfaceStub, StubFactoryBase, VapiInterface)
from vmware.vapi.bindings.common import raise_core_exception
from vmware.vapi.data.validator import (UnionValidator, HasFieldsOfValidator)
from vmware.vapi.exception import CoreException
from vmware.vapi.lib.constants import TaskType
from vmware.vapi.lib.rest import OperationRestMetadata


class CertificateProfile(VapiInterface):
    """
    
    """

    _VAPI_SERVICE_ID = 'com.vmware.nsx.trust_management.certificate_profile'
    """
    Identifier of the service in canonical form.
    """
    def __init__(self, config):
        """
        :type  config: :class:`vmware.vapi.bindings.stub.StubConfiguration`
        :param config: Configuration to be used for creating the stub.
        """
        VapiInterface.__init__(self, config, _CertificateProfileStub)
        self._VAPI_OPERATION_IDS = {}


    def get(self,
            service_type,
            ):
        """
        Get an available certificate profile. Note that not every service type
        has an active certificate profile.

        :type  service_type: :class:`str`
        :param service_type: Unique Service Type of the Certificate Profile (required)
        :rtype: :class:`com.vmware.nsx.model_client.CertificateProfile`
        :return: com.vmware.nsx.model.CertificateProfile
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('get',
                            {
                            'service_type': service_type,
                            })
class CertificateProfiles(VapiInterface):
    """
    
    """

    _VAPI_SERVICE_ID = 'com.vmware.nsx.trust_management.certificate_profiles'
    """
    Identifier of the service in canonical form.
    """
    def __init__(self, config):
        """
        :type  config: :class:`vmware.vapi.bindings.stub.StubConfiguration`
        :param config: Configuration to be used for creating the stub.
        """
        VapiInterface.__init__(self, config, _CertificateProfilesStub)
        self._VAPI_OPERATION_IDS = {}


    def list(self):
        """
        List the certificate profiles currently active on the NSX Manager. This
        list depends on the type of instance deployed and which certificates
        are currently managed through the certificate-profile manager. That
        list is expected to expand in future releases.


        :rtype: :class:`com.vmware.nsx.model_client.CertificateProfileListResult`
        :return: com.vmware.nsx.model.CertificateProfileListResult
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('list', None)
class Certificates(VapiInterface):
    """
    
    """
    APPLYCERTIFICATE_SERVICE_TYPE_MGMT_CLUSTER = "MGMT_CLUSTER"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_MGMT_PLANE = "MGMT_PLANE"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_API = "API"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_NOTIFICATION_COLLECTOR = "NOTIFICATION_COLLECTOR"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_SYSLOG_SERVER = "SYSLOG_SERVER"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_RSYSLOG_CLIENT = "RSYSLOG_CLIENT"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_APH = "APH"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_APH_TN = "APH_TN"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_GLOBAL_MANAGER = "GLOBAL_MANAGER"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_LOCAL_MANAGER = "LOCAL_MANAGER"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CLIENT_AUTH = "CLIENT_AUTH"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_RMQ = "RMQ"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_K8S_MSG_CLIENT = "K8S_MSG_CLIENT"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_WEB_PROXY = "WEB_PROXY"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CBM_API = "CBM_API"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CBM_CCP = "CBM_CCP"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CBM_CSM = "CBM_CSM"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CBM_MP = "CBM_MP"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CBM_GM = "CBM_GM"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CBM_AR = "CBM_AR"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CBM_MONITORING = "CBM_MONITORING"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CBM_IDPS_REPORTING = "CBM_IDPS_REPORTING"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CBM_CM_INVENTORY = "CBM_CM_INVENTORY"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CBM_MESSAGING_MANAGER = "CBM_MESSAGING_MANAGER"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CBM_UPGRADE_COORDINATOR = "CBM_UPGRADE_COORDINATOR"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CBM_SITE_MANAGER = "CBM_SITE_MANAGER"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CBM_CLUSTER_MANAGER = "CBM_CLUSTER_MANAGER"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CBM_CORFU = "CBM_CORFU"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CBM_SITE_PROXY_CLIENT = "CBM_SITE_PROXY_CLIENT"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_COMPUTE_MANAGER = "COMPUTE_MANAGER"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    APPLYCERTIFICATE_SERVICE_TYPE_CCP = "CCP"
    """
    Possible value for ``serviceType`` of method
    :func:`Certificates.applycertificate`.

    """
    LIST_TYPE_CLUSTER_API_CERTIFICATE = "cluster_api_certificate"
    """
    Possible value for ``type`` of method :func:`Certificates.list`.

    """
    LIST_TYPE_API_CERTIFICATE = "api_certificate"
    """
    Possible value for ``type`` of method :func:`Certificates.list`.

    """
    VALIDATE_USAGE_SERVER = "SERVER"
    """
    Possible value for ``usage`` of method :func:`Certificates.validate`.

    """
    VALIDATE_USAGE_CLIENT = "CLIENT"
    """
    Possible value for ``usage`` of method :func:`Certificates.validate`.

    """

    _VAPI_SERVICE_ID = 'com.vmware.nsx.trust_management.certificates'
    """
    Identifier of the service in canonical form.
    """
    def __init__(self, config):
        """
        :type  config: :class:`vmware.vapi.bindings.stub.StubConfiguration`
        :param config: Configuration to be used for creating the stub.
        """
        VapiInterface.__init__(self, config, _CertificatesStub)
        self._VAPI_OPERATION_IDS = {}


    def applycertificate(self,
                         cert_id,
                         service_type,
                         node_id=None,
                         ):
        """
        Look up the Certificate Profile matching the service-type and apply the
        certificate. When the Certificate Profile has
        cluster_certificate=false, the node_id parameter is required to
        designate the node where the certificate needs to be applied.

        :type  cert_id: :class:`str`
        :param cert_id: ID of certificate to apply (required)
        :type  service_type: :class:`str`
        :param service_type: Supported service types, that are using certificates. (required)
        :type  node_id: :class:`str` or ``None``
        :param node_id: Node Id (optional)
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('applycertificate',
                            {
                            'cert_id': cert_id,
                            'service_type': service_type,
                            'node_id': node_id,
                            })

    def delete(self,
               cert_id,
               ):
        """
        Removes the specified certificate. The private key associated with the
        certificate is also deleted.

        :type  cert_id: :class:`str`
        :param cert_id: ID of certificate to delete (required)
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('delete',
                            {
                            'cert_id': cert_id,
                            })

    def fetchpeercertificatechain(self,
                                  tls_service_endpoint,
                                  ):
        """
        Attempt to connect to an TLS service endpoint and retrieve the server
        certificate chain it presents.

        :type  tls_service_endpoint: :class:`com.vmware.nsx.model_client.TlsServiceEndpoint`
        :param tls_service_endpoint: (required)
        :rtype: :class:`com.vmware.nsx.model_client.PeerCertificateChain`
        :return: com.vmware.nsx.model.PeerCertificateChain
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('fetchpeercertificatechain',
                            {
                            'tls_service_endpoint': tls_service_endpoint,
                            })

    def get(self,
            cert_id,
            details=None,
            ):
        """
        Returns information for the specified certificate ID, including the
        certificate's UUID; resource_type (for example,
        certificate_self_signed, certificate_ca, or certificate_signed);
        pem_encoded data; and history of the certificate (who created or
        modified it and when). For additional information, include the
        ?details=true modifier at the end of the request URI.

        :type  cert_id: :class:`str`
        :param cert_id: ID of certificate to read (required)
        :type  details: :class:`bool` or ``None``
        :param details: whether to expand the pem data and show all its details (optional,
            default to false)
        :rtype: :class:`com.vmware.nsx.model_client.Certificate`
        :return: com.vmware.nsx.model.Certificate
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('get',
                            {
                            'cert_id': cert_id,
                            'details': details,
                            })

    def importcertificate(self,
                          trust_object_data,
                          ):
        """
        Adds a new private-public certificate or a chain of certificates (CAs)
        and, optionally, a private key that can be applied to one of the
        user-facing components (appliance management or edge). The certificate
        and the key should be stored in PEM format. If no private key is
        provided, the certificate is used as a client certificate in the trust
        store. A private key can be uploaded for a CA certificate only if the
        \"purpose\" parameter is set to \"signing-ca\".

        :type  trust_object_data: :class:`com.vmware.nsx.model_client.TrustObjectData`
        :param trust_object_data: (required)
        :rtype: :class:`com.vmware.nsx.model_client.CertificateList`
        :return: com.vmware.nsx.model.CertificateList
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('importcertificate',
                            {
                            'trust_object_data': trust_object_data,
                            })

    def importtrustedca(self,
                        alias,
                        trust_object_data,
                        ):
        """
        Add a CA certificate as a trust anchor

        :type  alias: :class:`str`
        :param alias: Alias under which to store the trusted CA in the trust-store
            (required)
        :type  trust_object_data: :class:`com.vmware.nsx.model_client.TrustObjectData`
        :param trust_object_data: (required)
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('importtrustedca',
                            {
                            'alias': alias,
                            'trust_object_data': trust_object_data,
                            })

    def list(self,
             cursor=None,
             details=None,
             included_fields=None,
             node_id=None,
             page_size=None,
             sort_ascending=None,
             sort_by=None,
             type=None,
             ):
        """
        Returns all certificate information viewable by the user, including
        each certificate's UUID; resource_type (for example,
        certificate_self_signed, certificate_ca, or certificate_signed);
        pem_encoded data; and history of the certificate (who created or
        modified it and when). For additional information, include the
        ?details=true modifier at the end of the request URI.

        :type  cursor: :class:`str` or ``None``
        :param cursor: Opaque cursor to be used for getting next page of records (supplied
            by current result page) (optional)
        :type  details: :class:`bool` or ``None``
        :param details: whether to expand the pem data and show all its details (optional,
            default to false)
        :type  included_fields: :class:`str` or ``None``
        :param included_fields: Comma separated list of fields that should be included in query
            result (optional)
        :type  node_id: :class:`str` or ``None``
        :param node_id: Node ID of certificate to return (optional)
        :type  page_size: :class:`long` or ``None``
        :param page_size: Maximum number of results to return in this page (server may return
            fewer) (optional, default to 1000)
        :type  sort_ascending: :class:`bool` or ``None``
        :param sort_ascending: (optional)
        :type  sort_by: :class:`str` or ``None``
        :param sort_by: Field by which records are sorted (optional)
        :type  type: :class:`str` or ``None``
        :param type: Type of certificate to return (optional)
        :rtype: :class:`com.vmware.nsx.model_client.CertificateList`
        :return: com.vmware.nsx.model.CertificateList
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('list',
                            {
                            'cursor': cursor,
                            'details': details,
                            'included_fields': included_fields,
                            'node_id': node_id,
                            'page_size': page_size,
                            'sort_ascending': sort_ascending,
                            'sort_by': sort_by,
                            'type': type,
                            })

    def setapplianceproxycertificateforintersitecommunication(self,
                                                              set_inter_site_aph_certificate_request,
                                                              ):
        """
        

        .. deprecated:: unknown

        :type  set_inter_site_aph_certificate_request: :class:`com.vmware.nsx.model_client.SetInterSiteAphCertificateRequest`
        :param set_inter_site_aph_certificate_request: (required)
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        warn('com.vmware.nsx.trust_management.Certificates.setapplianceproxycertificateforintersitecommunication is deprecated.', DeprecationWarning)
        return self._invoke('setapplianceproxycertificateforintersitecommunication',
                            {
                            'set_inter_site_aph_certificate_request': set_inter_site_aph_certificate_request,
                            })

    def setpicertificateforfederation(self,
                                      set_principal_identity_certificate_for_federation_request,
                                      ):
        """
        

        .. deprecated:: unknown

        :type  set_principal_identity_certificate_for_federation_request: :class:`com.vmware.nsx.model_client.SetPrincipalIdentityCertificateForFederationRequest`
        :param set_principal_identity_certificate_for_federation_request: (required)
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        warn('com.vmware.nsx.trust_management.Certificates.setpicertificateforfederation is deprecated.', DeprecationWarning)
        return self._invoke('setpicertificateforfederation',
                            {
                            'set_principal_identity_certificate_for_federation_request': set_principal_identity_certificate_for_federation_request,
                            })

    def validate(self,
                 cert_id,
                 usage=None,
                 ):
        """
        Checks whether certificate is valid. When the certificate contains a
        chain, the full chain is validated. The usage parameter can be SERVER
        (default) or CLIENT. This indicates whether the certificate needs to be
        validated as a server-auth or a client-auth certificate.

        :type  cert_id: :class:`str`
        :param cert_id: ID of certificate to validate (required)
        :type  usage: :class:`str` or ``None``
        :param usage: Usage Type of the Certificate, SERVER or CLIENT. Default is SERVER
            (optional)
        :rtype: :class:`com.vmware.nsx.model_client.CertificateCheckingStatus`
        :return: com.vmware.nsx.model.CertificateCheckingStatus
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('validate',
                            {
                            'cert_id': cert_id,
                            'usage': usage,
                            })
class CrlDistributionPoints(VapiInterface):
    """
    
    """

    _VAPI_SERVICE_ID = 'com.vmware.nsx.trust_management.crl_distribution_points'
    """
    Identifier of the service in canonical form.
    """
    def __init__(self, config):
        """
        :type  config: :class:`vmware.vapi.bindings.stub.StubConfiguration`
        :param config: Configuration to be used for creating the stub.
        """
        VapiInterface.__init__(self, config, _CrlDistributionPointsStub)
        self._VAPI_OPERATION_IDS = {}


    def create(self,
               crl_distribution_point,
               ):
        """
        Create an entity that will represent a Crl Distribution Point

        :type  crl_distribution_point: :class:`com.vmware.nsx.model_client.CrlDistributionPoint`
        :param crl_distribution_point: (required)
        :rtype: :class:`com.vmware.nsx.model_client.CrlDistributionPoint`
        :return: com.vmware.nsx.model.CrlDistributionPoint
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('create',
                            {
                            'crl_distribution_point': crl_distribution_point,
                            })

    def delete(self,
               crl_distribution_point_id,
               ):
        """
        Delete a CrlDistributionPoint. It does not delete the actual CRL.

        :type  crl_distribution_point_id: :class:`str`
        :param crl_distribution_point_id: Unique id of the CrlDistributionPoint to delete (required)
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('delete',
                            {
                            'crl_distribution_point_id': crl_distribution_point_id,
                            })

    def get(self,
            crl_distribution_point_id,
            ):
        """
        Return the CrlDistributionPoint with <crl-distribution-point-id>

        :type  crl_distribution_point_id: :class:`str`
        :param crl_distribution_point_id: (required)
        :rtype: :class:`com.vmware.nsx.model_client.CrlDistributionPoint`
        :return: com.vmware.nsx.model.CrlDistributionPoint
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('get',
                            {
                            'crl_distribution_point_id': crl_distribution_point_id,
                            })

    def list(self,
             cursor=None,
             included_fields=None,
             page_size=None,
             sort_ascending=None,
             sort_by=None,
             ):
        """
        Return the list of CrlDistributionPoints

        :type  cursor: :class:`str` or ``None``
        :param cursor: Opaque cursor to be used for getting next page of records (supplied
            by current result page) (optional)
        :type  included_fields: :class:`str` or ``None``
        :param included_fields: Comma separated list of fields that should be included in query
            result (optional)
        :type  page_size: :class:`long` or ``None``
        :param page_size: Maximum number of results to return in this page (server may return
            fewer) (optional, default to 1000)
        :type  sort_ascending: :class:`bool` or ``None``
        :param sort_ascending: (optional)
        :type  sort_by: :class:`str` or ``None``
        :param sort_by: Field by which records are sorted (optional)
        :rtype: :class:`com.vmware.nsx.model_client.CrlDistributionPointList`
        :return: com.vmware.nsx.model.CrlDistributionPointList
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('list',
                            {
                            'cursor': cursor,
                            'included_fields': included_fields,
                            'page_size': page_size,
                            'sort_ascending': sort_ascending,
                            'sort_by': sort_by,
                            })

    def update(self,
               crl_distribution_point_id,
               crl_distribution_point,
               ):
        """
        Update CrlDistributionPoint with <crl-distribution-point-id> This
        allows updating the ManagedResource fields.

        :type  crl_distribution_point_id: :class:`str`
        :param crl_distribution_point_id: (required)
        :type  crl_distribution_point: :class:`com.vmware.nsx.model_client.CrlDistributionPoint`
        :param crl_distribution_point: (required)
        :rtype: :class:`com.vmware.nsx.model_client.CrlDistributionPoint`
        :return: com.vmware.nsx.model.CrlDistributionPoint
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('update',
                            {
                            'crl_distribution_point_id': crl_distribution_point_id,
                            'crl_distribution_point': crl_distribution_point,
                            })
class Crls(VapiInterface):
    """
    
    """
    LIST_TYPE_CLUSTER_API_CERTIFICATE = "cluster_api_certificate"
    """
    Possible value for ``type`` of method :func:`Crls.list`.

    """
    LIST_TYPE_API_CERTIFICATE = "api_certificate"
    """
    Possible value for ``type`` of method :func:`Crls.list`.

    """

    _VAPI_SERVICE_ID = 'com.vmware.nsx.trust_management.crls'
    """
    Identifier of the service in canonical form.
    """
    def __init__(self, config):
        """
        :type  config: :class:`vmware.vapi.bindings.stub.StubConfiguration`
        :param config: Configuration to be used for creating the stub.
        """
        VapiInterface.__init__(self, config, _CrlsStub)
        self._VAPI_OPERATION_IDS = {}


    def delete(self,
               crl_id,
               ):
        """
        Deletes an existing CRL.

        :type  crl_id: :class:`str`
        :param crl_id: ID of CRL to delete (required)
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('delete',
                            {
                            'crl_id': crl_id,
                            })

    def get(self,
            crl_id,
            details=None,
            ):
        """
        Returns information about the specified CRL. For additional
        information, include the ?details=true modifier at the end of the
        request URI.

        :type  crl_id: :class:`str`
        :param crl_id: ID of CRL to read (required)
        :type  details: :class:`bool` or ``None``
        :param details: whether to expand the pem data and show all its details (optional,
            default to false)
        :rtype: :class:`com.vmware.nsx.model_client.Crl`
        :return: com.vmware.nsx.model.Crl
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('get',
                            {
                            'crl_id': crl_id,
                            'details': details,
                            })

    def importcrl(self,
                  crl_object_data,
                  ):
        """
        Adds a new certificate revocation list (CRL). The CRL is used to verify
        the client certificate status against the revocation lists published by
        the CA. For this reason, the administrator needs to add the CRL in
        certificate repository as well. A CRL can be in the PEM X.509 format
        (crl_type=X509) or JSON OneCRL (crl_type=OneCRL). If crl_type is not
        specified, it is auto-detected based on the presence of fields
        pem_encoded or one_crl.

        :type  crl_object_data: :class:`com.vmware.nsx.model_client.CrlObjectData`
        :param crl_object_data: (required)
        :rtype: :class:`com.vmware.nsx.model_client.CrlList`
        :return: com.vmware.nsx.model.CrlList
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('importcrl',
                            {
                            'crl_object_data': crl_object_data,
                            })

    def list(self,
             cursor=None,
             details=None,
             included_fields=None,
             node_id=None,
             page_size=None,
             sort_ascending=None,
             sort_by=None,
             type=None,
             ):
        """
        Returns information about all CRLs. For additional information, include
        the ?details=true modifier at the end of the request URI.

        :type  cursor: :class:`str` or ``None``
        :param cursor: Opaque cursor to be used for getting next page of records (supplied
            by current result page) (optional)
        :type  details: :class:`bool` or ``None``
        :param details: whether to expand the pem data and show all its details (optional,
            default to false)
        :type  included_fields: :class:`str` or ``None``
        :param included_fields: Comma separated list of fields that should be included in query
            result (optional)
        :type  node_id: :class:`str` or ``None``
        :param node_id: Node ID of certificate to return (optional)
        :type  page_size: :class:`long` or ``None``
        :param page_size: Maximum number of results to return in this page (server may return
            fewer) (optional, default to 1000)
        :type  sort_ascending: :class:`bool` or ``None``
        :param sort_ascending: (optional)
        :type  sort_by: :class:`str` or ``None``
        :param sort_by: Field by which records are sorted (optional)
        :type  type: :class:`str` or ``None``
        :param type: Type of certificate to return (optional)
        :rtype: :class:`com.vmware.nsx.model_client.CrlList`
        :return: com.vmware.nsx.model.CrlList
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('list',
                            {
                            'cursor': cursor,
                            'details': details,
                            'included_fields': included_fields,
                            'node_id': node_id,
                            'page_size': page_size,
                            'sort_ascending': sort_ascending,
                            'sort_by': sort_by,
                            'type': type,
                            })

    def update(self,
               crl_id,
               crl,
               ):
        """
        Updates an existing CRL.

        :type  crl_id: :class:`str`
        :param crl_id: ID of CRL to update (required)
        :type  crl: :class:`com.vmware.nsx.model_client.Crl`
        :param crl: (required)
        :rtype: :class:`com.vmware.nsx.model_client.Crl`
        :return: com.vmware.nsx.model.Crl
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('update',
                            {
                            'crl_id': crl_id,
                            'crl': crl,
                            })
class Csrs(VapiInterface):
    """
    
    """

    _VAPI_SERVICE_ID = 'com.vmware.nsx.trust_management.csrs'
    """
    Identifier of the service in canonical form.
    """
    def __init__(self, config):
        """
        :type  config: :class:`vmware.vapi.bindings.stub.StubConfiguration`
        :param config: Configuration to be used for creating the stub.
        """
        VapiInterface.__init__(self, config, _CsrsStub)
        self._VAPI_OPERATION_IDS = {}


    def create(self,
               csr,
               ):
        """
        Creates a new certificate signing request (CSR). A CSR is encrypted
        text that contains information about your organization (organization
        name, country, and so on) and your Web server's public key, which is a
        public certificate the is generated on the server that can be used to
        forward this request to a certificate authority (CA). A private key is
        also usually created at the same time as the CSR.

        :type  csr: :class:`com.vmware.nsx.model_client.Csr`
        :param csr: (required)
        :rtype: :class:`com.vmware.nsx.model_client.Csr`
        :return: com.vmware.nsx.model.Csr
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('create',
                            {
                            'csr': csr,
                            })

    def delete(self,
               csr_id,
               ):
        """
        Removes a specified CSR. If a CSR is not used for verification, you can
        delete it.

        :type  csr_id: :class:`str`
        :param csr_id: ID of CSR to delete (required)
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('delete',
                            {
                            'csr_id': csr_id,
                            })

    def get(self,
            csr_id,
            ):
        """
        Returns information about the specified CSR.

        :type  csr_id: :class:`str`
        :param csr_id: ID of CSR to read (required)
        :rtype: :class:`com.vmware.nsx.model_client.Csr`
        :return: com.vmware.nsx.model.Csr
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('get',
                            {
                            'csr_id': csr_id,
                            })

    def importcsr(self,
                  csr_id,
                  trust_object_data,
                  ):
        """
        Imports a certificate authority (CA)-signed certificate for a CSR. This
        action links the certificate to the private key created by the CSR. The
        pem_encoded string in the request body is the signed certificate
        provided by your CA in response to the CSR that you provide to them.
        After this operation you can delete the CSR.

        :type  csr_id: :class:`str`
        :param csr_id: CSR this certificate is associated with (required)
        :type  trust_object_data: :class:`com.vmware.nsx.model_client.TrustObjectData`
        :param trust_object_data: (required)
        :rtype: :class:`com.vmware.nsx.model_client.CertificateList`
        :return: com.vmware.nsx.model.CertificateList
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('importcsr',
                            {
                            'csr_id': csr_id,
                            'trust_object_data': trust_object_data,
                            })

    def list(self,
             cursor=None,
             included_fields=None,
             page_size=None,
             sort_ascending=None,
             sort_by=None,
             ):
        """
        Returns information about all of the CSRs that have been created.

        :type  cursor: :class:`str` or ``None``
        :param cursor: Opaque cursor to be used for getting next page of records (supplied
            by current result page) (optional)
        :type  included_fields: :class:`str` or ``None``
        :param included_fields: Comma separated list of fields that should be included in query
            result (optional)
        :type  page_size: :class:`long` or ``None``
        :param page_size: Maximum number of results to return in this page (server may return
            fewer) (optional, default to 1000)
        :type  sort_ascending: :class:`bool` or ``None``
        :param sort_ascending: (optional)
        :type  sort_by: :class:`str` or ``None``
        :param sort_by: Field by which records are sorted (optional)
        :rtype: :class:`com.vmware.nsx.model_client.CsrList`
        :return: com.vmware.nsx.model.CsrList
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('list',
                            {
                            'cursor': cursor,
                            'included_fields': included_fields,
                            'page_size': page_size,
                            'sort_ascending': sort_ascending,
                            'sort_by': sort_by,
                            })

    def selfsign(self,
                 csr_id,
                 days_valid,
                 ):
        """
        Self-signs the previously generated CSR. This action is similar to the
        import certificate action, but instead of using a public certificate
        signed by a CA, the self_sign POST action uses a certificate that is
        signed with NSX's own private key. For validity of non-CA certificates,
        if a value greater than 825 days is provided, it will be set to 825
        days. No limit is set for CA certificates.

        :type  csr_id: :class:`str`
        :param csr_id: CSR this certificate is associated with (required)
        :type  days_valid: :class:`long`
        :param days_valid: Number of days the certificate will be valid, default 825 days
            (required)
        :rtype: :class:`com.vmware.nsx.model_client.Certificate`
        :return: com.vmware.nsx.model.Certificate
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('selfsign',
                            {
                            'csr_id': csr_id,
                            'days_valid': days_valid,
                            })

    def selfsign_0(self,
                   csr_with_days_valid,
                   ):
        """
        Creates a new self-signed certificate. A private key is also created at
        the same time. This is convenience call that will generate a CSR and
        then self-sign it. For validity of non-CA certificates, if a value
        greater than 825 days is provided, it will be set to 825 days. No limit
        is set for CA certificates.

        :type  csr_with_days_valid: :class:`com.vmware.nsx.model_client.CsrWithDaysValid`
        :param csr_with_days_valid: (required)
        :rtype: :class:`com.vmware.nsx.model_client.Certificate`
        :return: com.vmware.nsx.model.Certificate
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('selfsign_0',
                            {
                            'csr_with_days_valid': csr_with_days_valid,
                            })
class CsrsExtended(VapiInterface):
    """
    
    """

    _VAPI_SERVICE_ID = 'com.vmware.nsx.trust_management.csrs_extended'
    """
    Identifier of the service in canonical form.
    """
    def __init__(self, config):
        """
        :type  config: :class:`vmware.vapi.bindings.stub.StubConfiguration`
        :param config: Configuration to be used for creating the stub.
        """
        VapiInterface.__init__(self, config, _CsrsExtendedStub)
        self._VAPI_OPERATION_IDS = {}


    def create(self,
               csr_ext,
               ):
        """
        Creates a new certificate signing request (CSR) with selected
        extensions. A CSR is encrypted text that contains information about
        your organization (organization name, country, and so on), additional
        attributes as extensions, and your Web server's public key, which is a
        public certificate the is generated on the server that can be used to
        forward this request to a certificate authority (CA). A private key is
        also usually created at the same time as the CSR.

        :type  csr_ext: :class:`com.vmware.nsx.model_client.CsrExt`
        :param csr_ext: (required)
        :rtype: :class:`com.vmware.nsx.model_client.Csr`
        :return: com.vmware.nsx.model.Csr
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('create',
                            {
                            'csr_ext': csr_ext,
                            })
class OidcUris(VapiInterface):
    """
    
    """
    LIST_OIDC_TYPE_VCENTER = "vcenter"
    """
    Possible value for ``oidcType`` of method :func:`OidcUris.list`.

    """
    LIST_OIDC_TYPE_WS_ONE = "ws_one"
    """
    Possible value for ``oidcType`` of method :func:`OidcUris.list`.

    """
    LIST_OIDC_TYPE_CSP = "csp"
    """
    Possible value for ``oidcType`` of method :func:`OidcUris.list`.

    """

    _VAPI_SERVICE_ID = 'com.vmware.nsx.trust_management.oidc_uris'
    """
    Identifier of the service in canonical form.
    """
    def __init__(self, config):
        """
        :type  config: :class:`vmware.vapi.bindings.stub.StubConfiguration`
        :param config: Configuration to be used for creating the stub.
        """
        VapiInterface.__init__(self, config, _OidcUrisStub)
        self._VAPI_OPERATION_IDS = {}


    def create(self,
               oidc_end_point,
               ):
        """
        This request also fetches the issuer and jwks_uri meta-data from the
        OIDC end-point and stores it.

        :type  oidc_end_point: :class:`com.vmware.nsx.model_client.OidcEndPoint`
        :param oidc_end_point: (required)
        :rtype: :class:`com.vmware.nsx.model_client.OidcEndPoint`
        :return: com.vmware.nsx.model.OidcEndPoint
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('create',
                            {
                            'oidc_end_point': oidc_end_point,
                            })

    def get(self,
            id,
            refresh=None,
            ):
        """
        When ?refresh=true is added to the request, the meta-data is newly
        fetched from the OIDC end-point.

        :type  id: :class:`str`
        :param id: (required)
        :type  refresh: :class:`bool` or ``None``
        :param refresh: Refresh meta-data (optional, default to false)
        :rtype: :class:`com.vmware.nsx.model_client.OidcEndPoint`
        :return: com.vmware.nsx.model.OidcEndPoint
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('get',
                            {
                            'id': id,
                            'refresh': refresh,
                            })

    def list(self,
             oidc_type=None,
             ):
        """
        Return the list of OpenID Connect end-points.

        :type  oidc_type: :class:`str` or ``None``
        :param oidc_type: Type of OIDC endpoint to return (optional)
        :rtype: :class:`com.vmware.nsx.model_client.OidcEndPointListResult`
        :return: com.vmware.nsx.model.OidcEndPointListResult
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('list',
                            {
                            'oidc_type': oidc_type,
                            })

    def refresh(self,
                id,
                ):
        """
        Refresh an OpenID Connect end-point by re-reading data from the OIDC
        URI.

        :type  id: :class:`str`
        :param id: (required)
        :rtype: :class:`com.vmware.nsx.model_client.OidcEndPoint`
        :return: com.vmware.nsx.model.OidcEndPoint
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('refresh',
                            {
                            'id': id,
                            })

    def update(self,
               id,
               oidc_end_point,
               ):
        """
        Update the properties of an OpenID Connect end-point. The oidc_uri
        property may not be changed. If you need to update the oidc_uri, you
        should delete the OIDC end-point and create a new one with the correct
        oidc_uri. This request also re-fetches the issuer, jwks_uri, and other
        meta-data from the OIDC end-point and stores it.

        :type  id: :class:`str`
        :param id: (required)
        :type  oidc_end_point: :class:`com.vmware.nsx.model_client.OidcEndPoint`
        :param oidc_end_point: (required)
        :rtype: :class:`com.vmware.nsx.model_client.OidcEndPoint`
        :return: com.vmware.nsx.model.OidcEndPoint
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('update',
                            {
                            'id': id,
                            'oidc_end_point': oidc_end_point,
                            })

    def updatethumbprint(self,
                         update_oidc_end_point_thumbprint_request,
                         ):
        """
        Update a OpenID Connect end-point's thumbprint used to connect to the
        oidc_uri through SSL

        :type  update_oidc_end_point_thumbprint_request: :class:`com.vmware.nsx.model_client.UpdateOidcEndPointThumbprintRequest`
        :param update_oidc_end_point_thumbprint_request: (required)
        :rtype: :class:`com.vmware.nsx.model_client.OidcEndPoint`
        :return: com.vmware.nsx.model.OidcEndPoint
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('updatethumbprint',
                            {
                            'update_oidc_end_point_thumbprint_request': update_oidc_end_point_thumbprint_request,
                            })
class PrincipalIdentities(VapiInterface):
    """
    
    """

    _VAPI_SERVICE_ID = 'com.vmware.nsx.trust_management.principal_identities'
    """
    Identifier of the service in canonical form.
    """
    def __init__(self, config):
        """
        :type  config: :class:`vmware.vapi.bindings.stub.StubConfiguration`
        :param config: Configuration to be used for creating the stub.
        """
        VapiInterface.__init__(self, config, _PrincipalIdentitiesStub)
        self._VAPI_OPERATION_IDS = {}


    def create(self,
               principal_identity,
               ):
        """
        Associates a principal's name with a certificate that is used to
        authenticate. The combination name and node_id needs to be unique
        across token-based and certificate-based principal identities. 
        Deprecated, use POST
        /trust-management/principal-identities/with-certificate instead.

        .. deprecated:: unknown

        :type  principal_identity: :class:`com.vmware.nsx.model_client.PrincipalIdentity`
        :param principal_identity: (required)
        :rtype: :class:`com.vmware.nsx.model_client.PrincipalIdentity`
        :return: com.vmware.nsx.model.PrincipalIdentity
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        warn('com.vmware.nsx.trust_management.PrincipalIdentities.create is deprecated.', DeprecationWarning)
        return self._invoke('create',
                            {
                            'principal_identity': principal_identity,
                            })

    def delete(self,
               principal_identity_id,
               ):
        """
        Delete a principal identity. It does not delete the certificate.

        :type  principal_identity_id: :class:`str`
        :param principal_identity_id: Unique id of the principal identity to delete (required)
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('delete',
                            {
                            'principal_identity_id': principal_identity_id,
                            })

    def get(self,
            principal_identity_id,
            ):
        """
        Get a stored principal identity

        :type  principal_identity_id: :class:`str`
        :param principal_identity_id: ID of the principal identity to get (required)
        :rtype: :class:`com.vmware.nsx.model_client.PrincipalIdentity`
        :return: com.vmware.nsx.model.PrincipalIdentity
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('get',
                            {
                            'principal_identity_id': principal_identity_id,
                            })

    def list(self):
        """
        Returns the list of principals registered with a certificate.


        :rtype: :class:`com.vmware.nsx.model_client.PrincipalIdentityList`
        :return: com.vmware.nsx.model.PrincipalIdentityList
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('list', None)

    def updatecertificate(self,
                          update_principal_identity_certificate_request,
                          ):
        """
        Update a principal identity's certificate

        :type  update_principal_identity_certificate_request: :class:`com.vmware.nsx.model_client.UpdatePrincipalIdentityCertificateRequest`
        :param update_principal_identity_certificate_request: (required)
        :rtype: :class:`com.vmware.nsx.model_client.PrincipalIdentity`
        :return: com.vmware.nsx.model.PrincipalIdentity
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('updatecertificate',
                            {
                            'update_principal_identity_certificate_request': update_principal_identity_certificate_request,
                            })
class TokenPrincipalIdentities(VapiInterface):
    """
    
    """

    _VAPI_SERVICE_ID = 'com.vmware.nsx.trust_management.token_principal_identities'
    """
    Identifier of the service in canonical form.
    """
    def __init__(self, config):
        """
        :type  config: :class:`vmware.vapi.bindings.stub.StubConfiguration`
        :param config: Configuration to be used for creating the stub.
        """
        VapiInterface.__init__(self, config, _TokenPrincipalIdentitiesStub)
        self._VAPI_OPERATION_IDS = {}


    def create(self,
               token_based_principal_identity,
               ):
        """
        Register a principal identity that is going to be authenticated through
        a token. The combination name and node_id needs to be unique across
        token-based and certificate-based principal identities.

        :type  token_based_principal_identity: :class:`com.vmware.nsx.model_client.TokenBasedPrincipalIdentity`
        :param token_based_principal_identity: (required)
        :rtype: :class:`com.vmware.nsx.model_client.TokenBasedPrincipalIdentity`
        :return: com.vmware.nsx.model.TokenBasedPrincipalIdentity
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('create',
                            {
                            'token_based_principal_identity': token_based_principal_identity,
                            })

    def delete(self,
               principal_identity_id,
               ):
        """
        Delete a token-based principal identity.

        :type  principal_identity_id: :class:`str`
        :param principal_identity_id: Unique id of the token-based principal identity to delete
            (required)
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('delete',
                            {
                            'principal_identity_id': principal_identity_id,
                            })

    def get(self,
            principal_identity_id,
            ):
        """
        Get a stored token-based principal identity

        :type  principal_identity_id: :class:`str`
        :param principal_identity_id: ID of the principal identity to get (required)
        :rtype: :class:`com.vmware.nsx.model_client.TokenBasedPrincipalIdentity`
        :return: com.vmware.nsx.model.TokenBasedPrincipalIdentity
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('get',
                            {
                            'principal_identity_id': principal_identity_id,
                            })

    def list(self):
        """
        Return the list of token-based principal identities. | These don't have
        certificate or role information.


        :rtype: :class:`com.vmware.nsx.model_client.TokenBasedPrincipalIdentityListResult`
        :return: com.vmware.nsx.model.TokenBasedPrincipalIdentityListResult
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('list', None)
class _CertificateProfileStub(ApiInterfaceStub):
    def __init__(self, config):
        # properties for get operation
        get_input_type = type.StructType('operation-input', {
            'service_type': type.StringType(),
        })
        get_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        get_input_value_validator_list = [
        ]
        get_output_validator_list = [
        ]
        get_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/certificate-profile/{service-type}',
            path_variables={
                'service_type': 'service-type',
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        operations = {
            'get': {
                'input_type': get_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'CertificateProfile'),
                'errors': get_error_dict,
                'input_value_validator_list': get_input_value_validator_list,
                'output_validator_list': get_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        rest_metadata = {
            'get': get_rest_metadata,
        }
        ApiInterfaceStub.__init__(
            self, iface_name='com.vmware.nsx.trust_management.certificate_profile',
            config=config, operations=operations, rest_metadata=rest_metadata,
            is_vapi_rest=False)

class _CertificateProfilesStub(ApiInterfaceStub):
    def __init__(self, config):
        # properties for list operation
        list_input_type = type.StructType('operation-input', {})
        list_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        list_input_value_validator_list = [
        ]
        list_output_validator_list = [
        ]
        list_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/certificate-profiles',
            path_variables={
            },
             header_parameters={
             },
            query_parameters={
            },
            content_type='application/json'
        )

        operations = {
            'list': {
                'input_type': list_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'CertificateProfileListResult'),
                'errors': list_error_dict,
                'input_value_validator_list': list_input_value_validator_list,
                'output_validator_list': list_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        rest_metadata = {
            'list': list_rest_metadata,
        }
        ApiInterfaceStub.__init__(
            self, iface_name='com.vmware.nsx.trust_management.certificate_profiles',
            config=config, operations=operations, rest_metadata=rest_metadata,
            is_vapi_rest=False)

class _CertificatesStub(ApiInterfaceStub):
    def __init__(self, config):
        # properties for applycertificate operation
        applycertificate_input_type = type.StructType('operation-input', {
            'cert_id': type.StringType(),
            'service_type': type.StringType(),
            'node_id': type.OptionalType(type.StringType()),
        })
        applycertificate_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        applycertificate_input_value_validator_list = [
        ]
        applycertificate_output_validator_list = [
        ]
        applycertificate_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/certificates/{cert-id}?action=apply_certificate',
            path_variables={
                'cert_id': 'cert-id',
            },
             header_parameters={
                   },
            query_parameters={
                'service_type': 'service_type',
                'node_id': 'node_id',
            },
            content_type='application/json'
        )

        # properties for delete operation
        delete_input_type = type.StructType('operation-input', {
            'cert_id': type.StringType(),
        })
        delete_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        delete_input_value_validator_list = [
        ]
        delete_output_validator_list = [
        ]
        delete_rest_metadata = OperationRestMetadata(
            http_method='DELETE',
            url_template='/api/v1/trust-management/certificates/{cert-id}',
            path_variables={
                'cert_id': 'cert-id',
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for fetchpeercertificatechain operation
        fetchpeercertificatechain_input_type = type.StructType('operation-input', {
            'tls_service_endpoint': type.ReferenceType('com.vmware.nsx.model_client', 'TlsServiceEndpoint'),
        })
        fetchpeercertificatechain_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        fetchpeercertificatechain_input_value_validator_list = [
        ]
        fetchpeercertificatechain_output_validator_list = [
        ]
        fetchpeercertificatechain_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/certificates?action=fetch_peer_certificate_chain',
            request_body_parameter='tls_service_endpoint',
            path_variables={
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for get operation
        get_input_type = type.StructType('operation-input', {
            'cert_id': type.StringType(),
            'details': type.OptionalType(type.BooleanType()),
        })
        get_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        get_input_value_validator_list = [
        ]
        get_output_validator_list = [
        ]
        get_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/certificates/{cert-id}',
            path_variables={
                'cert_id': 'cert-id',
            },
             header_parameters={
                 },
            query_parameters={
                'details': 'details',
            },
            content_type='application/json'
        )

        # properties for importcertificate operation
        importcertificate_input_type = type.StructType('operation-input', {
            'trust_object_data': type.ReferenceType('com.vmware.nsx.model_client', 'TrustObjectData'),
        })
        importcertificate_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        importcertificate_input_value_validator_list = [
        ]
        importcertificate_output_validator_list = [
        ]
        importcertificate_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/certificates?action=import',
            request_body_parameter='trust_object_data',
            path_variables={
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for importtrustedca operation
        importtrustedca_input_type = type.StructType('operation-input', {
            'alias': type.StringType(),
            'trust_object_data': type.ReferenceType('com.vmware.nsx.model_client', 'TrustObjectData'),
        })
        importtrustedca_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        importtrustedca_input_value_validator_list = [
        ]
        importtrustedca_output_validator_list = [
        ]
        importtrustedca_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/certificates/{alias}?action=import_trusted_ca',
            request_body_parameter='trust_object_data',
            path_variables={
                'alias': 'alias',
            },
             header_parameters={
                 },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for list operation
        list_input_type = type.StructType('operation-input', {
            'cursor': type.OptionalType(type.StringType()),
            'details': type.OptionalType(type.BooleanType()),
            'included_fields': type.OptionalType(type.StringType()),
            'node_id': type.OptionalType(type.StringType()),
            'page_size': type.OptionalType(type.IntegerType()),
            'sort_ascending': type.OptionalType(type.BooleanType()),
            'sort_by': type.OptionalType(type.StringType()),
            'type': type.OptionalType(type.StringType()),
        })
        list_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        list_input_value_validator_list = [
        ]
        list_output_validator_list = [
        ]
        list_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/certificates',
            path_variables={
            },
             header_parameters={
                             },
            query_parameters={
                'cursor': 'cursor',
                'details': 'details',
                'included_fields': 'included_fields',
                'node_id': 'node_id',
                'page_size': 'page_size',
                'sort_ascending': 'sort_ascending',
                'sort_by': 'sort_by',
                'type': 'type',
            },
            content_type='application/json'
        )

        # properties for setapplianceproxycertificateforintersitecommunication operation
        setapplianceproxycertificateforintersitecommunication_input_type = type.StructType('operation-input', {
            'set_inter_site_aph_certificate_request': type.ReferenceType('com.vmware.nsx.model_client', 'SetInterSiteAphCertificateRequest'),
        })
        setapplianceproxycertificateforintersitecommunication_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        setapplianceproxycertificateforintersitecommunication_input_value_validator_list = [
        ]
        setapplianceproxycertificateforintersitecommunication_output_validator_list = [
        ]
        setapplianceproxycertificateforintersitecommunication_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/certificates?action=set_appliance_proxy_certificate_for_inter_site_communication',
            request_body_parameter='set_inter_site_aph_certificate_request',
            path_variables={
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for setpicertificateforfederation operation
        setpicertificateforfederation_input_type = type.StructType('operation-input', {
            'set_principal_identity_certificate_for_federation_request': type.ReferenceType('com.vmware.nsx.model_client', 'SetPrincipalIdentityCertificateForFederationRequest'),
        })
        setpicertificateforfederation_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        setpicertificateforfederation_input_value_validator_list = [
        ]
        setpicertificateforfederation_output_validator_list = [
        ]
        setpicertificateforfederation_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/certificates?action=set_pi_certificate_for_federation',
            request_body_parameter='set_principal_identity_certificate_for_federation_request',
            path_variables={
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for validate operation
        validate_input_type = type.StructType('operation-input', {
            'cert_id': type.StringType(),
            'usage': type.OptionalType(type.StringType()),
        })
        validate_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        validate_input_value_validator_list = [
        ]
        validate_output_validator_list = [
        ]
        validate_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/certificates/{cert-id}?action=validate',
            path_variables={
                'cert_id': 'cert-id',
            },
             header_parameters={
                 },
            query_parameters={
                'usage': 'usage',
            },
            content_type='application/json'
        )

        operations = {
            'applycertificate': {
                'input_type': applycertificate_input_type,
                'output_type': type.VoidType(),
                'errors': applycertificate_error_dict,
                'input_value_validator_list': applycertificate_input_value_validator_list,
                'output_validator_list': applycertificate_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'delete': {
                'input_type': delete_input_type,
                'output_type': type.VoidType(),
                'errors': delete_error_dict,
                'input_value_validator_list': delete_input_value_validator_list,
                'output_validator_list': delete_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'fetchpeercertificatechain': {
                'input_type': fetchpeercertificatechain_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'PeerCertificateChain'),
                'errors': fetchpeercertificatechain_error_dict,
                'input_value_validator_list': fetchpeercertificatechain_input_value_validator_list,
                'output_validator_list': fetchpeercertificatechain_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'get': {
                'input_type': get_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'Certificate'),
                'errors': get_error_dict,
                'input_value_validator_list': get_input_value_validator_list,
                'output_validator_list': get_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'importcertificate': {
                'input_type': importcertificate_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'CertificateList'),
                'errors': importcertificate_error_dict,
                'input_value_validator_list': importcertificate_input_value_validator_list,
                'output_validator_list': importcertificate_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'importtrustedca': {
                'input_type': importtrustedca_input_type,
                'output_type': type.VoidType(),
                'errors': importtrustedca_error_dict,
                'input_value_validator_list': importtrustedca_input_value_validator_list,
                'output_validator_list': importtrustedca_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'list': {
                'input_type': list_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'CertificateList'),
                'errors': list_error_dict,
                'input_value_validator_list': list_input_value_validator_list,
                'output_validator_list': list_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'setapplianceproxycertificateforintersitecommunication': {
                'input_type': setapplianceproxycertificateforintersitecommunication_input_type,
                'output_type': type.VoidType(),
                'errors': setapplianceproxycertificateforintersitecommunication_error_dict,
                'input_value_validator_list': setapplianceproxycertificateforintersitecommunication_input_value_validator_list,
                'output_validator_list': setapplianceproxycertificateforintersitecommunication_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'setpicertificateforfederation': {
                'input_type': setpicertificateforfederation_input_type,
                'output_type': type.VoidType(),
                'errors': setpicertificateforfederation_error_dict,
                'input_value_validator_list': setpicertificateforfederation_input_value_validator_list,
                'output_validator_list': setpicertificateforfederation_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'validate': {
                'input_type': validate_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'CertificateCheckingStatus'),
                'errors': validate_error_dict,
                'input_value_validator_list': validate_input_value_validator_list,
                'output_validator_list': validate_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        rest_metadata = {
            'applycertificate': applycertificate_rest_metadata,
            'delete': delete_rest_metadata,
            'fetchpeercertificatechain': fetchpeercertificatechain_rest_metadata,
            'get': get_rest_metadata,
            'importcertificate': importcertificate_rest_metadata,
            'importtrustedca': importtrustedca_rest_metadata,
            'list': list_rest_metadata,
            'setapplianceproxycertificateforintersitecommunication': setapplianceproxycertificateforintersitecommunication_rest_metadata,
            'setpicertificateforfederation': setpicertificateforfederation_rest_metadata,
            'validate': validate_rest_metadata,
        }
        ApiInterfaceStub.__init__(
            self, iface_name='com.vmware.nsx.trust_management.certificates',
            config=config, operations=operations, rest_metadata=rest_metadata,
            is_vapi_rest=False)

class _CrlDistributionPointsStub(ApiInterfaceStub):
    def __init__(self, config):
        # properties for create operation
        create_input_type = type.StructType('operation-input', {
            'crl_distribution_point': type.ReferenceType('com.vmware.nsx.model_client', 'CrlDistributionPoint'),
        })
        create_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        create_input_value_validator_list = [
        ]
        create_output_validator_list = [
        ]
        create_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/crl-distribution-points',
            request_body_parameter='crl_distribution_point',
            path_variables={
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for delete operation
        delete_input_type = type.StructType('operation-input', {
            'crl_distribution_point_id': type.StringType(),
        })
        delete_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        delete_input_value_validator_list = [
        ]
        delete_output_validator_list = [
        ]
        delete_rest_metadata = OperationRestMetadata(
            http_method='DELETE',
            url_template='/api/v1/trust-management/crl-distribution-points/{crl-distribution-point-id}',
            path_variables={
                'crl_distribution_point_id': 'crl-distribution-point-id',
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for get operation
        get_input_type = type.StructType('operation-input', {
            'crl_distribution_point_id': type.StringType(),
        })
        get_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        get_input_value_validator_list = [
        ]
        get_output_validator_list = [
        ]
        get_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/crl-distribution-points/{crl-distribution-point-id}',
            path_variables={
                'crl_distribution_point_id': 'crl-distribution-point-id',
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for list operation
        list_input_type = type.StructType('operation-input', {
            'cursor': type.OptionalType(type.StringType()),
            'included_fields': type.OptionalType(type.StringType()),
            'page_size': type.OptionalType(type.IntegerType()),
            'sort_ascending': type.OptionalType(type.BooleanType()),
            'sort_by': type.OptionalType(type.StringType()),
        })
        list_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        list_input_value_validator_list = [
        ]
        list_output_validator_list = [
        ]
        list_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/crl-distribution-points',
            path_variables={
            },
             header_parameters={
                       },
            query_parameters={
                'cursor': 'cursor',
                'included_fields': 'included_fields',
                'page_size': 'page_size',
                'sort_ascending': 'sort_ascending',
                'sort_by': 'sort_by',
            },
            content_type='application/json'
        )

        # properties for update operation
        update_input_type = type.StructType('operation-input', {
            'crl_distribution_point_id': type.StringType(),
            'crl_distribution_point': type.ReferenceType('com.vmware.nsx.model_client', 'CrlDistributionPoint'),
        })
        update_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        update_input_value_validator_list = [
        ]
        update_output_validator_list = [
        ]
        update_rest_metadata = OperationRestMetadata(
            http_method='PUT',
            url_template='/api/v1/trust-management/crl-distribution-points/{crl-distribution-point-id}',
            request_body_parameter='crl_distribution_point',
            path_variables={
                'crl_distribution_point_id': 'crl-distribution-point-id',
            },
             header_parameters={
                 },
            query_parameters={
            },
            content_type='application/json'
        )

        operations = {
            'create': {
                'input_type': create_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'CrlDistributionPoint'),
                'errors': create_error_dict,
                'input_value_validator_list': create_input_value_validator_list,
                'output_validator_list': create_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'delete': {
                'input_type': delete_input_type,
                'output_type': type.VoidType(),
                'errors': delete_error_dict,
                'input_value_validator_list': delete_input_value_validator_list,
                'output_validator_list': delete_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'get': {
                'input_type': get_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'CrlDistributionPoint'),
                'errors': get_error_dict,
                'input_value_validator_list': get_input_value_validator_list,
                'output_validator_list': get_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'list': {
                'input_type': list_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'CrlDistributionPointList'),
                'errors': list_error_dict,
                'input_value_validator_list': list_input_value_validator_list,
                'output_validator_list': list_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'update': {
                'input_type': update_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'CrlDistributionPoint'),
                'errors': update_error_dict,
                'input_value_validator_list': update_input_value_validator_list,
                'output_validator_list': update_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        rest_metadata = {
            'create': create_rest_metadata,
            'delete': delete_rest_metadata,
            'get': get_rest_metadata,
            'list': list_rest_metadata,
            'update': update_rest_metadata,
        }
        ApiInterfaceStub.__init__(
            self, iface_name='com.vmware.nsx.trust_management.crl_distribution_points',
            config=config, operations=operations, rest_metadata=rest_metadata,
            is_vapi_rest=False)

class _CrlsStub(ApiInterfaceStub):
    def __init__(self, config):
        # properties for delete operation
        delete_input_type = type.StructType('operation-input', {
            'crl_id': type.StringType(),
        })
        delete_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        delete_input_value_validator_list = [
        ]
        delete_output_validator_list = [
        ]
        delete_rest_metadata = OperationRestMetadata(
            http_method='DELETE',
            url_template='/api/v1/trust-management/crls/{crl-id}',
            path_variables={
                'crl_id': 'crl-id',
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for get operation
        get_input_type = type.StructType('operation-input', {
            'crl_id': type.StringType(),
            'details': type.OptionalType(type.BooleanType()),
        })
        get_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        get_input_value_validator_list = [
        ]
        get_output_validator_list = [
        ]
        get_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/crls/{crl-id}',
            path_variables={
                'crl_id': 'crl-id',
            },
             header_parameters={
                 },
            query_parameters={
                'details': 'details',
            },
            content_type='application/json'
        )

        # properties for importcrl operation
        importcrl_input_type = type.StructType('operation-input', {
            'crl_object_data': type.ReferenceType('com.vmware.nsx.model_client', 'CrlObjectData'),
        })
        importcrl_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        importcrl_input_value_validator_list = [
        ]
        importcrl_output_validator_list = [
        ]
        importcrl_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/crls?action=import',
            request_body_parameter='crl_object_data',
            path_variables={
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for list operation
        list_input_type = type.StructType('operation-input', {
            'cursor': type.OptionalType(type.StringType()),
            'details': type.OptionalType(type.BooleanType()),
            'included_fields': type.OptionalType(type.StringType()),
            'node_id': type.OptionalType(type.StringType()),
            'page_size': type.OptionalType(type.IntegerType()),
            'sort_ascending': type.OptionalType(type.BooleanType()),
            'sort_by': type.OptionalType(type.StringType()),
            'type': type.OptionalType(type.StringType()),
        })
        list_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        list_input_value_validator_list = [
        ]
        list_output_validator_list = [
        ]
        list_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/crls',
            path_variables={
            },
             header_parameters={
                             },
            query_parameters={
                'cursor': 'cursor',
                'details': 'details',
                'included_fields': 'included_fields',
                'node_id': 'node_id',
                'page_size': 'page_size',
                'sort_ascending': 'sort_ascending',
                'sort_by': 'sort_by',
                'type': 'type',
            },
            content_type='application/json'
        )

        # properties for update operation
        update_input_type = type.StructType('operation-input', {
            'crl_id': type.StringType(),
            'crl': type.ReferenceType('com.vmware.nsx.model_client', 'Crl'),
        })
        update_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        update_input_value_validator_list = [
        ]
        update_output_validator_list = [
        ]
        update_rest_metadata = OperationRestMetadata(
            http_method='PUT',
            url_template='/api/v1/trust-management/crls/{crl-id}',
            request_body_parameter='crl',
            path_variables={
                'crl_id': 'crl-id',
            },
             header_parameters={
                 },
            query_parameters={
            },
            content_type='application/json'
        )

        operations = {
            'delete': {
                'input_type': delete_input_type,
                'output_type': type.VoidType(),
                'errors': delete_error_dict,
                'input_value_validator_list': delete_input_value_validator_list,
                'output_validator_list': delete_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'get': {
                'input_type': get_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'Crl'),
                'errors': get_error_dict,
                'input_value_validator_list': get_input_value_validator_list,
                'output_validator_list': get_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'importcrl': {
                'input_type': importcrl_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'CrlList'),
                'errors': importcrl_error_dict,
                'input_value_validator_list': importcrl_input_value_validator_list,
                'output_validator_list': importcrl_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'list': {
                'input_type': list_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'CrlList'),
                'errors': list_error_dict,
                'input_value_validator_list': list_input_value_validator_list,
                'output_validator_list': list_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'update': {
                'input_type': update_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'Crl'),
                'errors': update_error_dict,
                'input_value_validator_list': update_input_value_validator_list,
                'output_validator_list': update_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        rest_metadata = {
            'delete': delete_rest_metadata,
            'get': get_rest_metadata,
            'importcrl': importcrl_rest_metadata,
            'list': list_rest_metadata,
            'update': update_rest_metadata,
        }
        ApiInterfaceStub.__init__(
            self, iface_name='com.vmware.nsx.trust_management.crls',
            config=config, operations=operations, rest_metadata=rest_metadata,
            is_vapi_rest=False)

class _CsrsStub(ApiInterfaceStub):
    def __init__(self, config):
        # properties for create operation
        create_input_type = type.StructType('operation-input', {
            'csr': type.ReferenceType('com.vmware.nsx.model_client', 'Csr'),
        })
        create_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        create_input_value_validator_list = [
        ]
        create_output_validator_list = [
        ]
        create_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/csrs',
            request_body_parameter='csr',
            path_variables={
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for delete operation
        delete_input_type = type.StructType('operation-input', {
            'csr_id': type.StringType(),
        })
        delete_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        delete_input_value_validator_list = [
        ]
        delete_output_validator_list = [
        ]
        delete_rest_metadata = OperationRestMetadata(
            http_method='DELETE',
            url_template='/api/v1/trust-management/csrs/{csr-id}',
            path_variables={
                'csr_id': 'csr-id',
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for get operation
        get_input_type = type.StructType('operation-input', {
            'csr_id': type.StringType(),
        })
        get_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        get_input_value_validator_list = [
        ]
        get_output_validator_list = [
        ]
        get_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/csrs/{csr-id}',
            path_variables={
                'csr_id': 'csr-id',
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for importcsr operation
        importcsr_input_type = type.StructType('operation-input', {
            'csr_id': type.StringType(),
            'trust_object_data': type.ReferenceType('com.vmware.nsx.model_client', 'TrustObjectData'),
        })
        importcsr_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        importcsr_input_value_validator_list = [
        ]
        importcsr_output_validator_list = [
        ]
        importcsr_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/csrs/{csr-id}?action=import',
            request_body_parameter='trust_object_data',
            path_variables={
                'csr_id': 'csr-id',
            },
             header_parameters={
                 },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for list operation
        list_input_type = type.StructType('operation-input', {
            'cursor': type.OptionalType(type.StringType()),
            'included_fields': type.OptionalType(type.StringType()),
            'page_size': type.OptionalType(type.IntegerType()),
            'sort_ascending': type.OptionalType(type.BooleanType()),
            'sort_by': type.OptionalType(type.StringType()),
        })
        list_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        list_input_value_validator_list = [
        ]
        list_output_validator_list = [
        ]
        list_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/csrs',
            path_variables={
            },
             header_parameters={
                       },
            query_parameters={
                'cursor': 'cursor',
                'included_fields': 'included_fields',
                'page_size': 'page_size',
                'sort_ascending': 'sort_ascending',
                'sort_by': 'sort_by',
            },
            content_type='application/json'
        )

        # properties for selfsign operation
        selfsign_input_type = type.StructType('operation-input', {
            'csr_id': type.StringType(),
            'days_valid': type.IntegerType(),
        })
        selfsign_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        selfsign_input_value_validator_list = [
        ]
        selfsign_output_validator_list = [
        ]
        selfsign_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/csrs/{csr-id}?action=self_sign',
            path_variables={
                'csr_id': 'csr-id',
            },
             header_parameters={
                 },
            query_parameters={
                'days_valid': 'days_valid',
            },
            content_type='application/json'
        )

        # properties for selfsign_0 operation
        selfsign_0_input_type = type.StructType('operation-input', {
            'csr_with_days_valid': type.ReferenceType('com.vmware.nsx.model_client', 'CsrWithDaysValid'),
        })
        selfsign_0_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        selfsign_0_input_value_validator_list = [
        ]
        selfsign_0_output_validator_list = [
        ]
        selfsign_0_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/csrs?action=self_sign',
            request_body_parameter='csr_with_days_valid',
            path_variables={
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        operations = {
            'create': {
                'input_type': create_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'Csr'),
                'errors': create_error_dict,
                'input_value_validator_list': create_input_value_validator_list,
                'output_validator_list': create_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'delete': {
                'input_type': delete_input_type,
                'output_type': type.VoidType(),
                'errors': delete_error_dict,
                'input_value_validator_list': delete_input_value_validator_list,
                'output_validator_list': delete_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'get': {
                'input_type': get_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'Csr'),
                'errors': get_error_dict,
                'input_value_validator_list': get_input_value_validator_list,
                'output_validator_list': get_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'importcsr': {
                'input_type': importcsr_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'CertificateList'),
                'errors': importcsr_error_dict,
                'input_value_validator_list': importcsr_input_value_validator_list,
                'output_validator_list': importcsr_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'list': {
                'input_type': list_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'CsrList'),
                'errors': list_error_dict,
                'input_value_validator_list': list_input_value_validator_list,
                'output_validator_list': list_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'selfsign': {
                'input_type': selfsign_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'Certificate'),
                'errors': selfsign_error_dict,
                'input_value_validator_list': selfsign_input_value_validator_list,
                'output_validator_list': selfsign_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'selfsign_0': {
                'input_type': selfsign_0_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'Certificate'),
                'errors': selfsign_0_error_dict,
                'input_value_validator_list': selfsign_0_input_value_validator_list,
                'output_validator_list': selfsign_0_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        rest_metadata = {
            'create': create_rest_metadata,
            'delete': delete_rest_metadata,
            'get': get_rest_metadata,
            'importcsr': importcsr_rest_metadata,
            'list': list_rest_metadata,
            'selfsign': selfsign_rest_metadata,
            'selfsign_0': selfsign_0_rest_metadata,
        }
        ApiInterfaceStub.__init__(
            self, iface_name='com.vmware.nsx.trust_management.csrs',
            config=config, operations=operations, rest_metadata=rest_metadata,
            is_vapi_rest=False)

class _CsrsExtendedStub(ApiInterfaceStub):
    def __init__(self, config):
        # properties for create operation
        create_input_type = type.StructType('operation-input', {
            'csr_ext': type.ReferenceType('com.vmware.nsx.model_client', 'CsrExt'),
        })
        create_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        create_input_value_validator_list = [
        ]
        create_output_validator_list = [
        ]
        create_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/csrs-extended',
            request_body_parameter='csr_ext',
            path_variables={
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        operations = {
            'create': {
                'input_type': create_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'Csr'),
                'errors': create_error_dict,
                'input_value_validator_list': create_input_value_validator_list,
                'output_validator_list': create_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        rest_metadata = {
            'create': create_rest_metadata,
        }
        ApiInterfaceStub.__init__(
            self, iface_name='com.vmware.nsx.trust_management.csrs_extended',
            config=config, operations=operations, rest_metadata=rest_metadata,
            is_vapi_rest=False)

class _OidcUrisStub(ApiInterfaceStub):
    def __init__(self, config):
        # properties for create operation
        create_input_type = type.StructType('operation-input', {
            'oidc_end_point': type.ReferenceType('com.vmware.nsx.model_client', 'OidcEndPoint'),
        })
        create_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        create_input_value_validator_list = [
        ]
        create_output_validator_list = [
        ]
        create_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/oidc-uris',
            request_body_parameter='oidc_end_point',
            path_variables={
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for get operation
        get_input_type = type.StructType('operation-input', {
            'id': type.StringType(),
            'refresh': type.OptionalType(type.BooleanType()),
        })
        get_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        get_input_value_validator_list = [
        ]
        get_output_validator_list = [
        ]
        get_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/oidc-uris/{id}',
            path_variables={
                'id': 'id',
            },
             header_parameters={
                 },
            query_parameters={
                'refresh': 'refresh',
            },
            content_type='application/json'
        )

        # properties for list operation
        list_input_type = type.StructType('operation-input', {
            'oidc_type': type.OptionalType(type.StringType()),
        })
        list_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        list_input_value_validator_list = [
        ]
        list_output_validator_list = [
        ]
        list_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/oidc-uris',
            path_variables={
            },
             header_parameters={
               },
            query_parameters={
                'oidc_type': 'oidc_type',
            },
            content_type='application/json'
        )

        # properties for refresh operation
        refresh_input_type = type.StructType('operation-input', {
            'id': type.StringType(),
        })
        refresh_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        refresh_input_value_validator_list = [
        ]
        refresh_output_validator_list = [
        ]
        refresh_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/oidc-uris/{id}?action=refresh',
            path_variables={
                'id': 'id',
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for update operation
        update_input_type = type.StructType('operation-input', {
            'id': type.StringType(),
            'oidc_end_point': type.ReferenceType('com.vmware.nsx.model_client', 'OidcEndPoint'),
        })
        update_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        update_input_value_validator_list = [
        ]
        update_output_validator_list = [
        ]
        update_rest_metadata = OperationRestMetadata(
            http_method='PUT',
            url_template='/api/v1/trust-management/oidc-uris/{id}',
            request_body_parameter='oidc_end_point',
            path_variables={
                'id': 'id',
            },
             header_parameters={
                 },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for updatethumbprint operation
        updatethumbprint_input_type = type.StructType('operation-input', {
            'update_oidc_end_point_thumbprint_request': type.ReferenceType('com.vmware.nsx.model_client', 'UpdateOidcEndPointThumbprintRequest'),
        })
        updatethumbprint_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        updatethumbprint_input_value_validator_list = [
        ]
        updatethumbprint_output_validator_list = [
        ]
        updatethumbprint_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/oidc-uris?action=update_thumbprint',
            request_body_parameter='update_oidc_end_point_thumbprint_request',
            path_variables={
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        operations = {
            'create': {
                'input_type': create_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'OidcEndPoint'),
                'errors': create_error_dict,
                'input_value_validator_list': create_input_value_validator_list,
                'output_validator_list': create_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'get': {
                'input_type': get_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'OidcEndPoint'),
                'errors': get_error_dict,
                'input_value_validator_list': get_input_value_validator_list,
                'output_validator_list': get_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'list': {
                'input_type': list_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'OidcEndPointListResult'),
                'errors': list_error_dict,
                'input_value_validator_list': list_input_value_validator_list,
                'output_validator_list': list_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'refresh': {
                'input_type': refresh_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'OidcEndPoint'),
                'errors': refresh_error_dict,
                'input_value_validator_list': refresh_input_value_validator_list,
                'output_validator_list': refresh_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'update': {
                'input_type': update_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'OidcEndPoint'),
                'errors': update_error_dict,
                'input_value_validator_list': update_input_value_validator_list,
                'output_validator_list': update_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'updatethumbprint': {
                'input_type': updatethumbprint_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'OidcEndPoint'),
                'errors': updatethumbprint_error_dict,
                'input_value_validator_list': updatethumbprint_input_value_validator_list,
                'output_validator_list': updatethumbprint_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        rest_metadata = {
            'create': create_rest_metadata,
            'get': get_rest_metadata,
            'list': list_rest_metadata,
            'refresh': refresh_rest_metadata,
            'update': update_rest_metadata,
            'updatethumbprint': updatethumbprint_rest_metadata,
        }
        ApiInterfaceStub.__init__(
            self, iface_name='com.vmware.nsx.trust_management.oidc_uris',
            config=config, operations=operations, rest_metadata=rest_metadata,
            is_vapi_rest=False)

class _PrincipalIdentitiesStub(ApiInterfaceStub):
    def __init__(self, config):
        # properties for create operation
        create_input_type = type.StructType('operation-input', {
            'principal_identity': type.ReferenceType('com.vmware.nsx.model_client', 'PrincipalIdentity'),
        })
        create_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        create_input_value_validator_list = [
        ]
        create_output_validator_list = [
        ]
        create_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/principal-identities',
            request_body_parameter='principal_identity',
            path_variables={
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for delete operation
        delete_input_type = type.StructType('operation-input', {
            'principal_identity_id': type.StringType(),
        })
        delete_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        delete_input_value_validator_list = [
        ]
        delete_output_validator_list = [
        ]
        delete_rest_metadata = OperationRestMetadata(
            http_method='DELETE',
            url_template='/api/v1/trust-management/principal-identities/{principal-identity-id}',
            path_variables={
                'principal_identity_id': 'principal-identity-id',
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for get operation
        get_input_type = type.StructType('operation-input', {
            'principal_identity_id': type.StringType(),
        })
        get_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        get_input_value_validator_list = [
        ]
        get_output_validator_list = [
        ]
        get_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/principal-identities/{principal-identity-id}',
            path_variables={
                'principal_identity_id': 'principal-identity-id',
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for list operation
        list_input_type = type.StructType('operation-input', {})
        list_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        list_input_value_validator_list = [
        ]
        list_output_validator_list = [
        ]
        list_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/principal-identities',
            path_variables={
            },
             header_parameters={
             },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for updatecertificate operation
        updatecertificate_input_type = type.StructType('operation-input', {
            'update_principal_identity_certificate_request': type.ReferenceType('com.vmware.nsx.model_client', 'UpdatePrincipalIdentityCertificateRequest'),
        })
        updatecertificate_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        updatecertificate_input_value_validator_list = [
        ]
        updatecertificate_output_validator_list = [
        ]
        updatecertificate_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/principal-identities?action=update_certificate',
            request_body_parameter='update_principal_identity_certificate_request',
            path_variables={
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        operations = {
            'create': {
                'input_type': create_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'PrincipalIdentity'),
                'errors': create_error_dict,
                'input_value_validator_list': create_input_value_validator_list,
                'output_validator_list': create_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'delete': {
                'input_type': delete_input_type,
                'output_type': type.VoidType(),
                'errors': delete_error_dict,
                'input_value_validator_list': delete_input_value_validator_list,
                'output_validator_list': delete_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'get': {
                'input_type': get_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'PrincipalIdentity'),
                'errors': get_error_dict,
                'input_value_validator_list': get_input_value_validator_list,
                'output_validator_list': get_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'list': {
                'input_type': list_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'PrincipalIdentityList'),
                'errors': list_error_dict,
                'input_value_validator_list': list_input_value_validator_list,
                'output_validator_list': list_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'updatecertificate': {
                'input_type': updatecertificate_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'PrincipalIdentity'),
                'errors': updatecertificate_error_dict,
                'input_value_validator_list': updatecertificate_input_value_validator_list,
                'output_validator_list': updatecertificate_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        rest_metadata = {
            'create': create_rest_metadata,
            'delete': delete_rest_metadata,
            'get': get_rest_metadata,
            'list': list_rest_metadata,
            'updatecertificate': updatecertificate_rest_metadata,
        }
        ApiInterfaceStub.__init__(
            self, iface_name='com.vmware.nsx.trust_management.principal_identities',
            config=config, operations=operations, rest_metadata=rest_metadata,
            is_vapi_rest=False)

class _TokenPrincipalIdentitiesStub(ApiInterfaceStub):
    def __init__(self, config):
        # properties for create operation
        create_input_type = type.StructType('operation-input', {
            'token_based_principal_identity': type.ReferenceType('com.vmware.nsx.model_client', 'TokenBasedPrincipalIdentity'),
        })
        create_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        create_input_value_validator_list = [
        ]
        create_output_validator_list = [
        ]
        create_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/api/v1/trust-management/token-principal-identities',
            request_body_parameter='token_based_principal_identity',
            path_variables={
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for delete operation
        delete_input_type = type.StructType('operation-input', {
            'principal_identity_id': type.StringType(),
        })
        delete_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        delete_input_value_validator_list = [
        ]
        delete_output_validator_list = [
        ]
        delete_rest_metadata = OperationRestMetadata(
            http_method='DELETE',
            url_template='/api/v1/trust-management/token-principal-identities/{principal-identity-id}',
            path_variables={
                'principal_identity_id': 'principal-identity-id',
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for get operation
        get_input_type = type.StructType('operation-input', {
            'principal_identity_id': type.StringType(),
        })
        get_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        get_input_value_validator_list = [
        ]
        get_output_validator_list = [
        ]
        get_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/token-principal-identities/{principal-identity-id}',
            path_variables={
                'principal_identity_id': 'principal-identity-id',
            },
             header_parameters={
               },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for list operation
        list_input_type = type.StructType('operation-input', {})
        list_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        list_input_value_validator_list = [
        ]
        list_output_validator_list = [
        ]
        list_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/api/v1/trust-management/token-principal-identities',
            path_variables={
            },
             header_parameters={
             },
            query_parameters={
            },
            content_type='application/json'
        )

        operations = {
            'create': {
                'input_type': create_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'TokenBasedPrincipalIdentity'),
                'errors': create_error_dict,
                'input_value_validator_list': create_input_value_validator_list,
                'output_validator_list': create_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'delete': {
                'input_type': delete_input_type,
                'output_type': type.VoidType(),
                'errors': delete_error_dict,
                'input_value_validator_list': delete_input_value_validator_list,
                'output_validator_list': delete_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'get': {
                'input_type': get_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'TokenBasedPrincipalIdentity'),
                'errors': get_error_dict,
                'input_value_validator_list': get_input_value_validator_list,
                'output_validator_list': get_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'list': {
                'input_type': list_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx.model_client', 'TokenBasedPrincipalIdentityListResult'),
                'errors': list_error_dict,
                'input_value_validator_list': list_input_value_validator_list,
                'output_validator_list': list_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        rest_metadata = {
            'create': create_rest_metadata,
            'delete': delete_rest_metadata,
            'get': get_rest_metadata,
            'list': list_rest_metadata,
        }
        ApiInterfaceStub.__init__(
            self, iface_name='com.vmware.nsx.trust_management.token_principal_identities',
            config=config, operations=operations, rest_metadata=rest_metadata,
            is_vapi_rest=False)


class StubFactory(StubFactoryBase):
    _attrs = {
        'CertificateProfile': CertificateProfile,
        'CertificateProfiles': CertificateProfiles,
        'Certificates': Certificates,
        'CrlDistributionPoints': CrlDistributionPoints,
        'Crls': Crls,
        'Csrs': Csrs,
        'CsrsExtended': CsrsExtended,
        'OidcUris': OidcUris,
        'PrincipalIdentities': PrincipalIdentities,
        'TokenPrincipalIdentities': TokenPrincipalIdentities,
        'crl_distribution_points': 'com.vmware.nsx.trust_management.crl_distribution_points_client.StubFactory',
        'oidc_uris': 'com.vmware.nsx.trust_management.oidc_uris_client.StubFactory',
        'principal_identities': 'com.vmware.nsx.trust_management.principal_identities_client.StubFactory',
    }

