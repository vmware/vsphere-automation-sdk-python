"""
Setup file for vapi client bindings
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2012-2022 VMware, Inc.  All rights reserved. -- VMware Confidential'

import os
try:
    from setuptools import setup, find_packages
except ImportError:
    from distribute_setup import use_setuptools
    use_setuptools()
    from setuptools import setup, find_packages
from com.vmware.vapi import __version__

setup(
    name = 'vapi_client_bindings',
    url = 'https://github.com/vmware/vsphere-automation-sdk-python',
version = "4.0.0",
    author = 'VMware, Inc.',
    description = 'vapi client bindings for VMware vSphere Automation',
    packages = find_packages(),
    license_files = ['LICENSE'],
    license = 'MIT',
    classifiers = [],
    install_requires = [
        'setuptools',
        'vapi_runtime>=2.9.0',
    ]
)