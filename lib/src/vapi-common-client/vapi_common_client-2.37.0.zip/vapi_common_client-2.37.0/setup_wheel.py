"""
Setup file for vAPI Common Client package
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2017 VMware, Inc.  All rights reserved. -- VMware Confidential'


from setuptools import setup, find_packages
setup(
    name='vapi_common_client',
    version='2.37.0',
    packages=find_packages(),
    description='vAPI Common Services Client Bindings',
    install_requires=['vapi-runtime==2.37.0'],
    author='VMware',
)
