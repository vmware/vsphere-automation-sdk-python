"""
Setup file for creating Runtime package
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2017-2019, 2022 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long

try:
    from setuptools import setup, find_packages
except ImportError:
    from distribute_setup import use_setuptools
    use_setuptools()
    from setuptools import setup, find_packages  # pylint: disable=ungrouped-imports

import os

test_requirements = 'test-requirements.txt'
requirements = 'requirements.txt'
requirementsFile = os.path.join(os.path.dirname(__file__), requirements)
with open(requirementsFile) as f:
    required = f.read().splitlines()


setup(
    name='vapi_runtime',
    version='2.37.0',
    description='vAPI Runtime',
    classifiers=[],
    keywords='VMware',
    author='VMware',
    data_files=[('', [requirements, test_requirements])],
    packages=find_packages(),
    package_data={
        'vmware': ['vapi/settings/*.properties'],
    },
    include_package_data=True,
    zip_safe=False,
    install_requires=required,
    extras_require={
        'twisted': ['twisted>=18.0.0', 'service_identity>=18.0.0',
                    'lxml>=4.3.0', 'werkzeug>=0.14.1', 'urllib3>=1.25.1'],
        'server': ['lxml>=4.3.0', 'werkzeug>=0.14.1', 'urllib3>=1.25.1'],
    },
    entry_points={
        'console_scripts': [
            'vapi-server = vmware.vapi.server.vapid:main'
        ]
    }
)
