"""
Message Factory import for the bindings to use
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2015 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long

from vmware.vapi.message import MessageFactory  # pylint: disable=W0611
