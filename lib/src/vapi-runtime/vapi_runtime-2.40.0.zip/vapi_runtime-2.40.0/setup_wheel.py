"""
Setup file for creating Runtime package
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2017-2019, 2022 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long

try:
    from setuptools import setup, find_packages
except ImportError:
    from distribute_setup import use_setuptools
    use_setuptools()
    from setuptools import setup, find_packages  # pylint: disable=ungrouped-imports

import os

setup(
    name='vapi_runtime',
    version='2.40.0',
    description='vAPI Runtime',
    classifiers=[],
    keywords='VMware',
    author='VMware',
    data_files=[('', ['requirements.txt'])],
    packages=find_packages(),
    package_data={
        'vmware': ['vapi/settings/*.properties'],
    },
    include_package_data=True,
    zip_safe=False,
    install_requires=['pyOpenSSL',
                      'requests>=2.0.0,<3.0.0',
                      'six>=1.0.0,<2.0.0'],
    extras_require={
        'twisted': ['twisted>=18.0.0', 'service_identity>=18.0.0',
                    'lxml>=4.3.0', 'werkzeug>=0.14.1', 'urllib3>=1.25.1'],
        'server': ['lxml>=4.3.0', 'werkzeug>=0.14.1', 'urllib3>=1.25.1'],
    },
    entry_points={
        'console_scripts': [
            'vapi-server = vmware.vapi.server.vapid:main'
        ]
    }
)
