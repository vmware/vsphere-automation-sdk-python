"""
Setup file for vapi client bindings
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2018 VMware, Inc.  All rights reserved. -- VMware Confidential'

import os
try:
    from setuptools import setup, find_packages
except ImportError:
    from distribute_setup import use_setuptools
    use_setuptools()
    from setuptools import setup, find_packages


setup(
    name='vmc_draas_client_bindings',
    version=os.environ["SDK_BINDING_VERSION"],
    author = 'VMware, Inc.',
    description='Client bindings for Disaster Recovery As A Service',
    packages=find_packages(),
    license_files = ['LICENSE'],
    license = 'MIT',
    classifiers=[],
    install_requires=[
        'setuptools',
        'vapi_common_client',
        'vapi_runtime',
    ]
)