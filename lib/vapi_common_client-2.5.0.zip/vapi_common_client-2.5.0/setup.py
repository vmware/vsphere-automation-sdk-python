"""
Setup file for vAPI Common Client package
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright (c) 2015 VMware, Inc.  All rights reserved.'


from setuptools import setup, find_packages
setup(
    name='vapi_common_client',
    version='2.5.0',
    namespace_packages=['com'],
    packages=find_packages(),
    description='vAPI Common Services Client Bindings',
    install_requires=['vapi-runtime==2.5.0'],
    author='VMware',
)
