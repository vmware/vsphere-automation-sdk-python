# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------
# Copyright 2020 VMware, Inc.  All rights reserved.

# AUTO GENERATED FILE -- DO NOT MODIFY!
#
# vAPI stub file for package com.vmware.nsx_policy.aaa.
#---------------------------------------------------------------------------

"""


"""

__author__ = 'VMware, Inc.'
__docformat__ = 'restructuredtext en'

import sys

from vmware.vapi.bindings import type
from vmware.vapi.bindings.converter import TypeConverter
from vmware.vapi.bindings.enum import Enum
from vmware.vapi.bindings.error import VapiError
from vmware.vapi.bindings.struct import VapiStruct
from vmware.vapi.bindings.stub import (
    ApiInterfaceStub, StubFactoryBase, VapiInterface)
from vmware.vapi.bindings.common import raise_core_exception
from vmware.vapi.data.validator import (UnionValidator, HasFieldsOfValidator)
from vmware.vapi.exception import CoreException
from vmware.vapi.lib.constants import TaskType
from vmware.vapi.lib.rest import OperationRestMetadata


class LdapIdentitySources(VapiInterface):
    """
    
    """

    _VAPI_SERVICE_ID = 'com.vmware.nsx_policy.aaa.ldap_identity_sources'
    """
    Identifier of the service in canonical form.
    """
    def __init__(self, config):
        """
        :type  config: :class:`vmware.vapi.bindings.stub.StubConfiguration`
        :param config: Configuration to be used for creating the stub.
        """
        VapiInterface.__init__(self, config, _LdapIdentitySourcesStub)
        self._VAPI_OPERATION_IDS = {}


    def delete(self,
               ldap_identity_source_id,
               ):
        """
        Delete an LDAP identity source. Users defined in that source will no
        longer be able to access NSX.

        :type  ldap_identity_source_id: :class:`str`
        :param ldap_identity_source_id: (required)
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('delete',
                            {
                            'ldap_identity_source_id': ldap_identity_source_id,
                            })

    def fetchcertificate(self,
                         identity_source_ldap_server_endpoint,
                         ):
        """
        Attempt to connect to an LDAP server and retrieve the server
        certificate it presents.

        :type  identity_source_ldap_server_endpoint: :class:`com.vmware.nsx_policy.model_client.IdentitySourceLdapServerEndpoint`
        :param identity_source_ldap_server_endpoint: (required)
        :rtype: :class:`com.vmware.nsx_policy.model_client.PeerCertificateChain`
        :return: com.vmware.nsx_policy.model.PeerCertificateChain
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('fetchcertificate',
                            {
                            'identity_source_ldap_server_endpoint': identity_source_ldap_server_endpoint,
                            })

    def get(self,
            ldap_identity_source_id,
            ):
        """
        Return details about one LDAP identity source

        :type  ldap_identity_source_id: :class:`str`
        :param ldap_identity_source_id: (required)
        :rtype: :class:`vmware.vapi.struct.VapiStruct`
        :return: com.vmware.nsx_policy.model.LdapIdentitySource
            The return value will contain all the attributes defined in
            :class:`com.vmware.nsx_policy.model_client.LdapIdentitySource`.
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('get',
                            {
                            'ldap_identity_source_id': ldap_identity_source_id,
                            })

    def list(self,
             cursor=None,
             included_fields=None,
             page_size=None,
             sort_ascending=None,
             sort_by=None,
             ):
        """
        Return a list of all configured LDAP identity sources.

        :type  cursor: :class:`str` or ``None``
        :param cursor: Opaque cursor to be used for getting next page of records (supplied
            by current result page) (optional)
        :type  included_fields: :class:`str` or ``None``
        :param included_fields: Comma separated list of fields that should be included in query
            result (optional)
        :type  page_size: :class:`long` or ``None``
        :param page_size: Maximum number of results to return in this page (server may return
            fewer) (optional, default to 1000)
        :type  sort_ascending: :class:`bool` or ``None``
        :param sort_ascending: (optional)
        :type  sort_by: :class:`str` or ``None``
        :param sort_by: Field by which records are sorted (optional)
        :rtype: :class:`com.vmware.nsx_policy.model_client.LdapIdentitySourceListResult`
        :return: com.vmware.nsx_policy.model.LdapIdentitySourceListResult
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('list',
                            {
                            'cursor': cursor,
                            'included_fields': included_fields,
                            'page_size': page_size,
                            'sort_ascending': sort_ascending,
                            'sort_by': sort_by,
                            })

    def probe(self,
              ldap_identity_source_id,
              ):
        """
        Attempt to connect to an existing LDAP identity source and report any
        errors encountered.

        :type  ldap_identity_source_id: :class:`str`
        :param ldap_identity_source_id: (required)
        :rtype: :class:`com.vmware.nsx_policy.model_client.LdapIdentitySourceProbeResults`
        :return: com.vmware.nsx_policy.model.LdapIdentitySourceProbeResults
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('probe',
                            {
                            'ldap_identity_source_id': ldap_identity_source_id,
                            })

    def probeidentitysource(self,
                            ldap_identity_source,
                            ):
        """
        Verify that the configuration of an LDAP identity source is correct
        before actually creating the source.

        :type  ldap_identity_source: :class:`vmware.vapi.struct.VapiStruct`
        :param ldap_identity_source: (required)
            The parameter must contain all the attributes defined in
            :class:`com.vmware.nsx_policy.model_client.LdapIdentitySource`.
        :rtype: :class:`com.vmware.nsx_policy.model_client.LdapIdentitySourceProbeResults`
        :return: com.vmware.nsx_policy.model.LdapIdentitySourceProbeResults
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('probeidentitysource',
                            {
                            'ldap_identity_source': ldap_identity_source,
                            })

    def probeldapserver(self,
                        identity_source_ldap_server,
                        ):
        """
        Attempt to connect to an LDAP server and ensure that the server can be
        contacted using the given URL and authentication credentials.

        :type  identity_source_ldap_server: :class:`com.vmware.nsx_policy.model_client.IdentitySourceLdapServer`
        :param identity_source_ldap_server: (required)
        :rtype: :class:`com.vmware.nsx_policy.model_client.IdentitySourceLdapServerProbeResult`
        :return: com.vmware.nsx_policy.model.IdentitySourceLdapServerProbeResult
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('probeldapserver',
                            {
                            'identity_source_ldap_server': identity_source_ldap_server,
                            })

    def update(self,
               ldap_identity_source_id,
               ldap_identity_source,
               ):
        """
        Update the configuration of an existing LDAP identity source. You may
        wish to verify the new configuration using the POST
        /aaa/ldap-identity-sources?action=probe API before changing the
        configuration.

        :type  ldap_identity_source_id: :class:`str`
        :param ldap_identity_source_id: (required)
        :type  ldap_identity_source: :class:`vmware.vapi.struct.VapiStruct`
        :param ldap_identity_source: (required)
            The parameter must contain all the attributes defined in
            :class:`com.vmware.nsx_policy.model_client.LdapIdentitySource`.
        :rtype: :class:`vmware.vapi.struct.VapiStruct`
        :return: com.vmware.nsx_policy.model.LdapIdentitySource
            The return value will contain all the attributes defined in
            :class:`com.vmware.nsx_policy.model_client.LdapIdentitySource`.
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        return self._invoke('update',
                            {
                            'ldap_identity_source_id': ldap_identity_source_id,
                            'ldap_identity_source': ldap_identity_source,
                            })
class _LdapIdentitySourcesStub(ApiInterfaceStub):
    def __init__(self, config):
        # properties for delete operation
        delete_input_type = type.StructType('operation-input', {
            'ldap_identity_source_id': type.StringType(),
        })
        delete_error_dict = {
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        delete_input_value_validator_list = [
        ]
        delete_output_validator_list = [
        ]
        delete_rest_metadata = OperationRestMetadata(
            http_method='DELETE',
            url_template='/policy/api/v1/aaa/ldap-identity-sources/{ldap-identity-source-id}',
            path_variables={
                'ldap_identity_source_id': 'ldap-identity-source-id',
            },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for fetchcertificate operation
        fetchcertificate_input_type = type.StructType('operation-input', {
            'identity_source_ldap_server_endpoint': type.ReferenceType('com.vmware.nsx_policy.model_client', 'IdentitySourceLdapServerEndpoint'),
        })
        fetchcertificate_error_dict = {
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        fetchcertificate_input_value_validator_list = [
        ]
        fetchcertificate_output_validator_list = [
        ]
        fetchcertificate_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/policy/api/v1/aaa/ldap-identity-sources?action=fetch_certificate',
            request_body_parameter='identity_source_ldap_server_endpoint',
            path_variables={
            },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for get operation
        get_input_type = type.StructType('operation-input', {
            'ldap_identity_source_id': type.StringType(),
        })
        get_error_dict = {
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        get_input_value_validator_list = [
        ]
        get_output_validator_list = [
            HasFieldsOfValidator()
        ]
        get_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/policy/api/v1/aaa/ldap-identity-sources/{ldap-identity-source-id}',
            path_variables={
                'ldap_identity_source_id': 'ldap-identity-source-id',
            },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for list operation
        list_input_type = type.StructType('operation-input', {
            'cursor': type.OptionalType(type.StringType()),
            'included_fields': type.OptionalType(type.StringType()),
            'page_size': type.OptionalType(type.IntegerType()),
            'sort_ascending': type.OptionalType(type.BooleanType()),
            'sort_by': type.OptionalType(type.StringType()),
        })
        list_error_dict = {
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        list_input_value_validator_list = [
        ]
        list_output_validator_list = [
            HasFieldsOfValidator()
        ]
        list_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/policy/api/v1/aaa/ldap-identity-sources',
            path_variables={
            },
            query_parameters={
                'cursor': 'cursor',
                'included_fields': 'included_fields',
                'page_size': 'page_size',
                'sort_ascending': 'sort_ascending',
                'sort_by': 'sort_by',
            },
            content_type='application/json'
        )

        # properties for probe operation
        probe_input_type = type.StructType('operation-input', {
            'ldap_identity_source_id': type.StringType(),
        })
        probe_error_dict = {
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        probe_input_value_validator_list = [
        ]
        probe_output_validator_list = [
        ]
        probe_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/policy/api/v1/aaa/ldap-identity-sources/{ldap-identity-source-id}?action=probe',
            path_variables={
                'ldap_identity_source_id': 'ldap-identity-source-id',
            },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for probeidentitysource operation
        probeidentitysource_input_type = type.StructType('operation-input', {
            'ldap_identity_source': type.DynamicStructType('vmware.vapi.dynamic_struct', {}, VapiStruct, [type.ReferenceType('com.vmware.nsx_policy.model_client', 'LdapIdentitySource')]),
        })
        probeidentitysource_error_dict = {
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        probeidentitysource_input_value_validator_list = [
            HasFieldsOfValidator()
        ]
        probeidentitysource_output_validator_list = [
        ]
        probeidentitysource_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/policy/api/v1/aaa/ldap-identity-sources?action=probe_identity_source',
            request_body_parameter='ldap_identity_source',
            path_variables={
            },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for probeldapserver operation
        probeldapserver_input_type = type.StructType('operation-input', {
            'identity_source_ldap_server': type.ReferenceType('com.vmware.nsx_policy.model_client', 'IdentitySourceLdapServer'),
        })
        probeldapserver_error_dict = {
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        probeldapserver_input_value_validator_list = [
        ]
        probeldapserver_output_validator_list = [
        ]
        probeldapserver_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/policy/api/v1/aaa/ldap-identity-sources?action=probe_ldap_server',
            request_body_parameter='identity_source_ldap_server',
            path_variables={
            },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for update operation
        update_input_type = type.StructType('operation-input', {
            'ldap_identity_source_id': type.StringType(),
            'ldap_identity_source': type.DynamicStructType('vmware.vapi.dynamic_struct', {}, VapiStruct, [type.ReferenceType('com.vmware.nsx_policy.model_client', 'LdapIdentitySource')]),
        })
        update_error_dict = {
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        update_input_value_validator_list = [
            HasFieldsOfValidator()
        ]
        update_output_validator_list = [
            HasFieldsOfValidator()
        ]
        update_rest_metadata = OperationRestMetadata(
            http_method='PUT',
            url_template='/policy/api/v1/aaa/ldap-identity-sources/{ldap-identity-source-id}',
            request_body_parameter='ldap_identity_source',
            path_variables={
                'ldap_identity_source_id': 'ldap-identity-source-id',
            },
            query_parameters={
            },
            content_type='application/json'
        )

        operations = {
            'delete': {
                'input_type': delete_input_type,
                'output_type': type.VoidType(),
                'errors': delete_error_dict,
                'input_value_validator_list': delete_input_value_validator_list,
                'output_validator_list': delete_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'fetchcertificate': {
                'input_type': fetchcertificate_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx_policy.model_client', 'PeerCertificateChain'),
                'errors': fetchcertificate_error_dict,
                'input_value_validator_list': fetchcertificate_input_value_validator_list,
                'output_validator_list': fetchcertificate_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'get': {
                'input_type': get_input_type,
                'output_type': type.DynamicStructType('vmware.vapi.dynamic_struct', {}, VapiStruct, [type.ReferenceType('com.vmware.nsx_policy.model_client', 'LdapIdentitySource')]),
                'errors': get_error_dict,
                'input_value_validator_list': get_input_value_validator_list,
                'output_validator_list': get_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'list': {
                'input_type': list_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx_policy.model_client', 'LdapIdentitySourceListResult'),
                'errors': list_error_dict,
                'input_value_validator_list': list_input_value_validator_list,
                'output_validator_list': list_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'probe': {
                'input_type': probe_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx_policy.model_client', 'LdapIdentitySourceProbeResults'),
                'errors': probe_error_dict,
                'input_value_validator_list': probe_input_value_validator_list,
                'output_validator_list': probe_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'probeidentitysource': {
                'input_type': probeidentitysource_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx_policy.model_client', 'LdapIdentitySourceProbeResults'),
                'errors': probeidentitysource_error_dict,
                'input_value_validator_list': probeidentitysource_input_value_validator_list,
                'output_validator_list': probeidentitysource_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'probeldapserver': {
                'input_type': probeldapserver_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx_policy.model_client', 'IdentitySourceLdapServerProbeResult'),
                'errors': probeldapserver_error_dict,
                'input_value_validator_list': probeldapserver_input_value_validator_list,
                'output_validator_list': probeldapserver_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'update': {
                'input_type': update_input_type,
                'output_type': type.DynamicStructType('vmware.vapi.dynamic_struct', {}, VapiStruct, [type.ReferenceType('com.vmware.nsx_policy.model_client', 'LdapIdentitySource')]),
                'errors': update_error_dict,
                'input_value_validator_list': update_input_value_validator_list,
                'output_validator_list': update_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        rest_metadata = {
            'delete': delete_rest_metadata,
            'fetchcertificate': fetchcertificate_rest_metadata,
            'get': get_rest_metadata,
            'list': list_rest_metadata,
            'probe': probe_rest_metadata,
            'probeidentitysource': probeidentitysource_rest_metadata,
            'probeldapserver': probeldapserver_rest_metadata,
            'update': update_rest_metadata,
        }
        ApiInterfaceStub.__init__(
            self, iface_name='com.vmware.nsx_policy.aaa.ldap_identity_sources',
            config=config, operations=operations, rest_metadata=rest_metadata,
            is_vapi_rest=False)


class StubFactory(StubFactoryBase):
    _attrs = {
        'LdapIdentitySources': LdapIdentitySources,
        'ldap_identity_sources': 'com.vmware.nsx_policy.aaa.ldap_identity_sources_client.StubFactory',
    }

