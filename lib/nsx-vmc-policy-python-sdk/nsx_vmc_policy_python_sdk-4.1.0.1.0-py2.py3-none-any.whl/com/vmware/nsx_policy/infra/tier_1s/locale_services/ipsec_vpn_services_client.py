# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------
# Copyright 2023 VMware, Inc.  All rights reserved.

# AUTO GENERATED FILE -- DO NOT MODIFY!
#
# vAPI stub file for package com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.
#---------------------------------------------------------------------------

"""


"""

__author__ = 'VMware, Inc.'
__docformat__ = 'restructuredtext en'

import sys
from warnings import warn

from vmware.vapi.bindings import type
from vmware.vapi.bindings.converter import TypeConverter
from vmware.vapi.bindings.enum import Enum
from vmware.vapi.bindings.error import VapiError
from vmware.vapi.bindings.struct import VapiStruct
from vmware.vapi.bindings.stub import (
    ApiInterfaceStub, StubFactoryBase, VapiInterface)
from vmware.vapi.bindings.common import raise_core_exception
from vmware.vapi.data.validator import (UnionValidator, HasFieldsOfValidator)
from vmware.vapi.exception import CoreException
from vmware.vapi.lib.constants import TaskType
from vmware.vapi.lib.rest import OperationRestMetadata


class LocalEndpoints(VapiInterface):
    """
    
    """

    _VAPI_SERVICE_ID = 'com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.local_endpoints'
    """
    Identifier of the service in canonical form.
    """
    def __init__(self, config):
        """
        :type  config: :class:`vmware.vapi.bindings.stub.StubConfiguration`
        :param config: Configuration to be used for creating the stub.
        """
        VapiInterface.__init__(self, config, _LocalEndpointsStub)
        self._VAPI_OPERATION_IDS = {}


    def delete(self,
               tier1_id,
               locale_service_id,
               service_id,
               local_endpoint_id,
               ):
        """
        Delete IPSec VPN local endpoint for a given locale service under
        Tier-1. 
        This API is deprecated. Please use DELETE
        /infra/tier-1s/<tier-1-id>/ipsec-vpn-services/<service-id>/
        local-endpoints/<local-endpoint-id> instead. Note: Please note that
        request is validated and any error messages returned from validation
        may include the new VPN path instead of the deprecated path. Both new
        path and old path refer to same resource. Also VPN path returned in the
        Alarm, GPRR payload may include the new VPN path

        .. deprecated:: unknown

        :type  tier1_id: :class:`str`
        :param tier1_id: (required)
        :type  locale_service_id: :class:`str`
        :param locale_service_id: (required)
        :type  service_id: :class:`str`
        :param service_id: (required)
        :type  local_endpoint_id: :class:`str`
        :param local_endpoint_id: (required)
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        warn('com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.LocalEndpoints.delete is deprecated.', DeprecationWarning)
        return self._invoke('delete',
                            {
                            'tier1_id': tier1_id,
                            'locale_service_id': locale_service_id,
                            'service_id': service_id,
                            'local_endpoint_id': local_endpoint_id,
                            })

    def get(self,
            tier1_id,
            locale_service_id,
            service_id,
            local_endpoint_id,
            ):
        """
        Get IPSec VPN local endpoint for a given locale service under Tier-1. 
        This API is deprecated. Please use GET
        /infra/tier-1s/<tier-1-id>/ipsec-vpn-services/<service-id>/
        local-endpoints/<local-endpoint-id> instead. Note: Please note that
        request is validated and any error messages returned from validation
        may include the new VPN path instead of the deprecated path. Both new
        path and old path refer to same resource.

        .. deprecated:: unknown

        :type  tier1_id: :class:`str`
        :param tier1_id: (required)
        :type  locale_service_id: :class:`str`
        :param locale_service_id: (required)
        :type  service_id: :class:`str`
        :param service_id: (required)
        :type  local_endpoint_id: :class:`str`
        :param local_endpoint_id: (required)
        :rtype: :class:`com.vmware.nsx_policy.model_client.IPSecVpnLocalEndpoint`
        :return: com.vmware.nsx_policy.model.IPSecVpnLocalEndpoint
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        warn('com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.LocalEndpoints.get is deprecated.', DeprecationWarning)
        return self._invoke('get',
                            {
                            'tier1_id': tier1_id,
                            'locale_service_id': locale_service_id,
                            'service_id': service_id,
                            'local_endpoint_id': local_endpoint_id,
                            })

    def list(self,
             tier1_id,
             locale_service_id,
             service_id,
             cursor=None,
             include_mark_for_delete_objects=None,
             included_fields=None,
             page_size=None,
             sort_ascending=None,
             sort_by=None,
             ):
        """
        Get paginated list of all IPSec VPN local endpoints for a given locale
        service under Tier-1. 
        This API is deprecated. Please use GET
        /infra/tier-1s/<tier-1-id>/ipsec-vpn-services/<service-id>/local-endpoints
        instead. Note: Please note that request is validated and any error
        messages returned from validation may include the new VPN path instead
        of the deprecated path. Both new path and old path refer to same
        resource.

        .. deprecated:: unknown

        :type  tier1_id: :class:`str`
        :param tier1_id: (required)
        :type  locale_service_id: :class:`str`
        :param locale_service_id: (required)
        :type  service_id: :class:`str`
        :param service_id: (required)
        :type  cursor: :class:`str` or ``None``
        :param cursor: Opaque cursor to be used for getting next page of records (supplied
            by current result page) (optional)
        :type  include_mark_for_delete_objects: :class:`bool` or ``None``
        :param include_mark_for_delete_objects: Include objects that are marked for deletion in results (optional,
            default to false)
        :type  included_fields: :class:`str` or ``None``
        :param included_fields: Comma separated list of fields that should be included in query
            result (optional)
        :type  page_size: :class:`long` or ``None``
        :param page_size: Maximum number of results to return in this page (server may return
            fewer) (optional, default to 1000)
        :type  sort_ascending: :class:`bool` or ``None``
        :param sort_ascending: (optional)
        :type  sort_by: :class:`str` or ``None``
        :param sort_by: Field by which records are sorted (optional)
        :rtype: :class:`com.vmware.nsx_policy.model_client.IPSecVpnLocalEndpointListResult`
        :return: com.vmware.nsx_policy.model.IPSecVpnLocalEndpointListResult
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        warn('com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.LocalEndpoints.list is deprecated.', DeprecationWarning)
        return self._invoke('list',
                            {
                            'tier1_id': tier1_id,
                            'locale_service_id': locale_service_id,
                            'service_id': service_id,
                            'cursor': cursor,
                            'include_mark_for_delete_objects': include_mark_for_delete_objects,
                            'included_fields': included_fields,
                            'page_size': page_size,
                            'sort_ascending': sort_ascending,
                            'sort_by': sort_by,
                            })

    def patch(self,
              tier1_id,
              locale_service_id,
              service_id,
              local_endpoint_id,
              ip_sec_vpn_local_endpoint,
              ):
        """
        Create or patch a custom IPSec VPN local endpoint for a given locale
        service under Tier-1. 
        This API is deprecated. Please use PATCH
        /infra/tier-1s/<tier-1-id>/ipsec-vpn-services/<service-id>/
        local-endpoints/<local-endpoint-id> instead. Note: Please note that
        request is validated and any error messages returned from validation
        may include the new VPN path instead of the deprecated path. Both new
        path and old path refer to same resource. Also VPN path returned in the
        Alarm, GPRR payload may include the new VPN path

        .. deprecated:: unknown

        :type  tier1_id: :class:`str`
        :param tier1_id: (required)
        :type  locale_service_id: :class:`str`
        :param locale_service_id: (required)
        :type  service_id: :class:`str`
        :param service_id: (required)
        :type  local_endpoint_id: :class:`str`
        :param local_endpoint_id: (required)
        :type  ip_sec_vpn_local_endpoint: :class:`com.vmware.nsx_policy.model_client.IPSecVpnLocalEndpoint`
        :param ip_sec_vpn_local_endpoint: (required)
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        warn('com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.LocalEndpoints.patch is deprecated.', DeprecationWarning)
        return self._invoke('patch',
                            {
                            'tier1_id': tier1_id,
                            'locale_service_id': locale_service_id,
                            'service_id': service_id,
                            'local_endpoint_id': local_endpoint_id,
                            'ip_sec_vpn_local_endpoint': ip_sec_vpn_local_endpoint,
                            })

    def update(self,
               tier1_id,
               locale_service_id,
               service_id,
               local_endpoint_id,
               ip_sec_vpn_local_endpoint,
               ):
        """
        Create or fully replace IPSec VPN local endpoint for a given locale
        service under Tier-1. Revision is optional for creation and required
        for update. 
        This API is deprecated. Please use PUT
        /infra/tier-1s/<tier-1-id>/ipsec-vpn-services/<service-id>/
        local-endpoints/<local-endpoint-id> instead. Note: Please note that
        request is validated and any error messages returned from validation
        may include the new VPN path instead of the deprecated path. Both new
        path and old path refer to same resource. Also VPN path returned in the
        Alarm, GPRR payload may include the new VPN path

        .. deprecated:: unknown

        :type  tier1_id: :class:`str`
        :param tier1_id: (required)
        :type  locale_service_id: :class:`str`
        :param locale_service_id: (required)
        :type  service_id: :class:`str`
        :param service_id: (required)
        :type  local_endpoint_id: :class:`str`
        :param local_endpoint_id: (required)
        :type  ip_sec_vpn_local_endpoint: :class:`com.vmware.nsx_policy.model_client.IPSecVpnLocalEndpoint`
        :param ip_sec_vpn_local_endpoint: (required)
        :rtype: :class:`com.vmware.nsx_policy.model_client.IPSecVpnLocalEndpoint`
        :return: com.vmware.nsx_policy.model.IPSecVpnLocalEndpoint
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        warn('com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.LocalEndpoints.update is deprecated.', DeprecationWarning)
        return self._invoke('update',
                            {
                            'tier1_id': tier1_id,
                            'locale_service_id': locale_service_id,
                            'service_id': service_id,
                            'local_endpoint_id': local_endpoint_id,
                            'ip_sec_vpn_local_endpoint': ip_sec_vpn_local_endpoint,
                            })
class Sessions(VapiInterface):
    """
    
    """

    _VAPI_SERVICE_ID = 'com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.sessions'
    """
    Identifier of the service in canonical form.
    """
    def __init__(self, config):
        """
        :type  config: :class:`vmware.vapi.bindings.stub.StubConfiguration`
        :param config: Configuration to be used for creating the stub.
        """
        VapiInterface.__init__(self, config, _SessionsStub)
        self._VAPI_OPERATION_IDS = {}


    def delete(self,
               tier1_id,
               locale_service_id,
               service_id,
               session_id,
               ):
        """
        Delete IPSec VPN session for a given locale service under Tier-1. 
        This API is deprecated. Please use DELETE
        /infra/tier-1s/<tier-1-id>/ipsec-vpn-services/<service-id>/
        sessions/<session-id> instead. Note: Please note that request is
        validated and any error messages returned from validation may include
        the new VPN path instead of the deprecated path. Both new path and old
        path refer to same resource. Also VPN path returned in the Alarm, GPRR
        payload may include the new VPN path.

        .. deprecated:: unknown

        :type  tier1_id: :class:`str`
        :param tier1_id: (required)
        :type  locale_service_id: :class:`str`
        :param locale_service_id: (required)
        :type  service_id: :class:`str`
        :param service_id: (required)
        :type  session_id: :class:`str`
        :param session_id: (required)
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        warn('com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.Sessions.delete is deprecated.', DeprecationWarning)
        return self._invoke('delete',
                            {
                            'tier1_id': tier1_id,
                            'locale_service_id': locale_service_id,
                            'service_id': service_id,
                            'session_id': session_id,
                            })

    def get(self,
            tier1_id,
            locale_service_id,
            service_id,
            session_id,
            ):
        """
        Get IPSec VPN session without sensitive data for a given locale service
        under Tier-1. 
        This API is deprecated. Please use GET
        /infra/tier-1s/<tier-1-id>/ipsec-vpn-services/<service-id>/sessions/<session-id>
        instead. Note: Please note that request is validated and any error
        messages returned from validation may include the new VPN path instead
        of the deprecated path. Both new path and old path refer to same
        resource.

        .. deprecated:: unknown

        :type  tier1_id: :class:`str`
        :param tier1_id: (required)
        :type  locale_service_id: :class:`str`
        :param locale_service_id: (required)
        :type  service_id: :class:`str`
        :param service_id: (required)
        :type  session_id: :class:`str`
        :param session_id: (required)
        :rtype: :class:`vmware.vapi.struct.VapiStruct`
        :return: com.vmware.nsx_policy.model.IPSecVpnSession
            The return value will contain all the attributes defined in
            :class:`com.vmware.nsx_policy.model_client.IPSecVpnSession`.
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        warn('com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.Sessions.get is deprecated.', DeprecationWarning)
        return self._invoke('get',
                            {
                            'tier1_id': tier1_id,
                            'locale_service_id': locale_service_id,
                            'service_id': service_id,
                            'session_id': session_id,
                            })

    def list(self,
             tier1_id,
             locale_service_id,
             service_id,
             cursor=None,
             include_mark_for_delete_objects=None,
             included_fields=None,
             page_size=None,
             sort_ascending=None,
             sort_by=None,
             ):
        """
        Get paginated list of all IPSec VPN sessions for a given locale service
        under Tier-1. 
        This API is deprecated. Please use GET
        /infra/tier-1s/<tier-1-id>/ipsec-vpn-services/<service-id>/sessions
        instead. Note: Please note that request is validated and any error
        messages returned from validation may include the new VPN path instead
        of the deprecated path. Both new path and old path refer to same
        resource.

        .. deprecated:: unknown

        :type  tier1_id: :class:`str`
        :param tier1_id: (required)
        :type  locale_service_id: :class:`str`
        :param locale_service_id: (required)
        :type  service_id: :class:`str`
        :param service_id: (required)
        :type  cursor: :class:`str` or ``None``
        :param cursor: Opaque cursor to be used for getting next page of records (supplied
            by current result page) (optional)
        :type  include_mark_for_delete_objects: :class:`bool` or ``None``
        :param include_mark_for_delete_objects: Include objects that are marked for deletion in results (optional,
            default to false)
        :type  included_fields: :class:`str` or ``None``
        :param included_fields: Comma separated list of fields that should be included in query
            result (optional)
        :type  page_size: :class:`long` or ``None``
        :param page_size: Maximum number of results to return in this page (server may return
            fewer) (optional, default to 1000)
        :type  sort_ascending: :class:`bool` or ``None``
        :param sort_ascending: (optional)
        :type  sort_by: :class:`str` or ``None``
        :param sort_by: Field by which records are sorted (optional)
        :rtype: :class:`com.vmware.nsx_policy.model_client.IPSecVpnSessionListResult`
        :return: com.vmware.nsx_policy.model.IPSecVpnSessionListResult
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        warn('com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.Sessions.list is deprecated.', DeprecationWarning)
        return self._invoke('list',
                            {
                            'tier1_id': tier1_id,
                            'locale_service_id': locale_service_id,
                            'service_id': service_id,
                            'cursor': cursor,
                            'include_mark_for_delete_objects': include_mark_for_delete_objects,
                            'included_fields': included_fields,
                            'page_size': page_size,
                            'sort_ascending': sort_ascending,
                            'sort_by': sort_by,
                            })

    def patch(self,
              tier1_id,
              locale_service_id,
              service_id,
              session_id,
              ip_sec_vpn_session,
              ):
        """
        Create or patch an IPSec VPN session for a given locale service under
        Tier-1. 
        This API is deprecated. Please use PATCH
        /infra/tier-1s/<tier-1-id>/ipsec-vpn-services/<service-id>/sessions/<session-id>
        instead. Note: Please note that request is validated and any error
        messages returned from validation may include the new VPN path instead
        of the deprecated path. Both new path and old path refer to same
        resource. Also VPN path returned in the Alarm, GPRR payload may include
        the new VPN path

        .. deprecated:: unknown

        :type  tier1_id: :class:`str`
        :param tier1_id: (required)
        :type  locale_service_id: :class:`str`
        :param locale_service_id: (required)
        :type  service_id: :class:`str`
        :param service_id: (required)
        :type  session_id: :class:`str`
        :param session_id: (required)
        :type  ip_sec_vpn_session: :class:`vmware.vapi.struct.VapiStruct`
        :param ip_sec_vpn_session: (required)
            The parameter must contain all the attributes defined in
            :class:`com.vmware.nsx_policy.model_client.IPSecVpnSession`.
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        warn('com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.Sessions.patch is deprecated.', DeprecationWarning)
        return self._invoke('patch',
                            {
                            'tier1_id': tier1_id,
                            'locale_service_id': locale_service_id,
                            'service_id': service_id,
                            'session_id': session_id,
                            'ip_sec_vpn_session': ip_sec_vpn_session,
                            })

    def showsensitivedata(self,
                          tier1_id,
                          locale_service_id,
                          service_id,
                          session_id,
                          ):
        """
        Get IPSec VPN session with senstive data for a given locale service
        under Tier-1. 
        This API is deprecated. Please use GET
        /infra/tier-1s/<tier-1-id>/ipsec-vpn-services/<service-id>/sessions/<session-id>?action=show_sensitive_data
        instead. Note: Please note that request is validated and any error
        messages returned from validation may include the new VPN path instead
        of the deprecated path. Both new path and old path refer to same
        resource.

        .. deprecated:: unknown

        :type  tier1_id: :class:`str`
        :param tier1_id: (required)
        :type  locale_service_id: :class:`str`
        :param locale_service_id: (required)
        :type  service_id: :class:`str`
        :param service_id: (required)
        :type  session_id: :class:`str`
        :param session_id: (required)
        :rtype: :class:`vmware.vapi.struct.VapiStruct`
        :return: com.vmware.nsx_policy.model.IPSecVpnSession
            The return value will contain all the attributes defined in
            :class:`com.vmware.nsx_policy.model_client.IPSecVpnSession`.
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        warn('com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.Sessions.showsensitivedata is deprecated.', DeprecationWarning)
        return self._invoke('showsensitivedata',
                            {
                            'tier1_id': tier1_id,
                            'locale_service_id': locale_service_id,
                            'service_id': service_id,
                            'session_id': session_id,
                            })

    def update(self,
               tier1_id,
               locale_service_id,
               service_id,
               session_id,
               ip_sec_vpn_session,
               ):
        """
        Create or fully replace IPSec VPN session for a given locale service
        under Tier-1. Revision is optional for creation and required for
        update. 
        This API is deprecated. Please use PUT
        /infra/tier-1s/<tier-1-id>/ipsec-vpn-services/<service-id>/sessions/<session-id>
        instead. Note: Please note that request is validated and any error
        messages returned from validation may include the new VPN path instead
        of the deprecated path. Both new path and old path refer to same
        resource. Also VPN path returned in the Alarm, GPRR payload may include
        the new VPN path.

        .. deprecated:: unknown

        :type  tier1_id: :class:`str`
        :param tier1_id: (required)
        :type  locale_service_id: :class:`str`
        :param locale_service_id: (required)
        :type  service_id: :class:`str`
        :param service_id: (required)
        :type  session_id: :class:`str`
        :param session_id: (required)
        :type  ip_sec_vpn_session: :class:`vmware.vapi.struct.VapiStruct`
        :param ip_sec_vpn_session: (required)
            The parameter must contain all the attributes defined in
            :class:`com.vmware.nsx_policy.model_client.IPSecVpnSession`.
        :rtype: :class:`vmware.vapi.struct.VapiStruct`
        :return: com.vmware.nsx_policy.model.IPSecVpnSession
            The return value will contain all the attributes defined in
            :class:`com.vmware.nsx_policy.model_client.IPSecVpnSession`.
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        warn('com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.Sessions.update is deprecated.', DeprecationWarning)
        return self._invoke('update',
                            {
                            'tier1_id': tier1_id,
                            'locale_service_id': locale_service_id,
                            'service_id': service_id,
                            'session_id': session_id,
                            'ip_sec_vpn_session': ip_sec_vpn_session,
                            })
class Summary(VapiInterface):
    """
    
    """
    GET_SOURCE_REALTIME = "realtime"
    """
    Possible value for ``source`` of method :func:`Summary.get`.

    """
    GET_SOURCE_CACHED = "cached"
    """
    Possible value for ``source`` of method :func:`Summary.get`.

    """

    _VAPI_SERVICE_ID = 'com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.summary'
    """
    Identifier of the service in canonical form.
    """
    def __init__(self, config):
        """
        :type  config: :class:`vmware.vapi.bindings.stub.StubConfiguration`
        :param config: Configuration to be used for creating the stub.
        """
        VapiInterface.__init__(self, config, _SummaryStub)
        self._VAPI_OPERATION_IDS = {}


    def get(self,
            tier1_id,
            locale_service_id,
            service_id,
            enforcement_point_path=None,
            source=None,
            ):
        """
        Summarized view of all tier-1 IPSec VPN sessions for a specified
        service. 
        This API is deprecated. Please use GET
        /infra/tier-1s/<tier-1-id>/ipsec-vpn-services/<service-id>/summary
        instead.

        .. deprecated:: unknown

        :type  tier1_id: :class:`str`
        :param tier1_id: (required)
        :type  locale_service_id: :class:`str`
        :param locale_service_id: (required)
        :type  service_id: :class:`str`
        :param service_id: (required)
        :type  enforcement_point_path: :class:`str` or ``None``
        :param enforcement_point_path: String Path of the enforcement point (optional)
        :type  source: :class:`str` or ``None``
        :param source: Data source type. (optional)
        :rtype: :class:`com.vmware.nsx_policy.model_client.PolicyIpsecVpnIkeServiceSummary`
        :return: com.vmware.nsx_policy.model.PolicyIpsecVpnIkeServiceSummary
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidRequest` 
             Bad Request, Precondition Failed
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
             Forbidden
        :raise: :class:`com.vmware.vapi.std.errors_client.ServiceUnavailable` 
             Service Unavailable
        :raise: :class:`com.vmware.vapi.std.errors_client.InternalServerError` 
             Internal Server Error
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             Not Found
        """
        warn('com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.Summary.get is deprecated.', DeprecationWarning)
        return self._invoke('get',
                            {
                            'tier1_id': tier1_id,
                            'locale_service_id': locale_service_id,
                            'service_id': service_id,
                            'enforcement_point_path': enforcement_point_path,
                            'source': source,
                            })
class _LocalEndpointsStub(ApiInterfaceStub):
    def __init__(self, config):
        # properties for delete operation
        delete_input_type = type.StructType('operation-input', {
            'tier1_id': type.StringType(),
            'locale_service_id': type.StringType(),
            'service_id': type.StringType(),
            'local_endpoint_id': type.StringType(),
        })
        delete_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        delete_input_value_validator_list = [
        ]
        delete_output_validator_list = [
        ]
        delete_rest_metadata = OperationRestMetadata(
            http_method='DELETE',
            url_template='/policy/api/v1/infra/tier-1s/{tier-1-id}/locale-services/{locale-service-id}/ipsec-vpn-services/{service-id}/local-endpoints/{local-endpoint-id}',
            path_variables={
                'tier1_id': 'tier-1-id',
                'locale_service_id': 'locale-service-id',
                'service_id': 'service-id',
                'local_endpoint_id': 'local-endpoint-id',
            },
             header_parameters={
                     },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for get operation
        get_input_type = type.StructType('operation-input', {
            'tier1_id': type.StringType(),
            'locale_service_id': type.StringType(),
            'service_id': type.StringType(),
            'local_endpoint_id': type.StringType(),
        })
        get_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        get_input_value_validator_list = [
        ]
        get_output_validator_list = [
            HasFieldsOfValidator()
        ]
        get_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/policy/api/v1/infra/tier-1s/{tier-1-id}/locale-services/{locale-service-id}/ipsec-vpn-services/{service-id}/local-endpoints/{local-endpoint-id}',
            path_variables={
                'tier1_id': 'tier-1-id',
                'locale_service_id': 'locale-service-id',
                'service_id': 'service-id',
                'local_endpoint_id': 'local-endpoint-id',
            },
             header_parameters={
                     },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for list operation
        list_input_type = type.StructType('operation-input', {
            'tier1_id': type.StringType(),
            'locale_service_id': type.StringType(),
            'service_id': type.StringType(),
            'cursor': type.OptionalType(type.StringType()),
            'include_mark_for_delete_objects': type.OptionalType(type.BooleanType()),
            'included_fields': type.OptionalType(type.StringType()),
            'page_size': type.OptionalType(type.IntegerType()),
            'sort_ascending': type.OptionalType(type.BooleanType()),
            'sort_by': type.OptionalType(type.StringType()),
        })
        list_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        list_input_value_validator_list = [
        ]
        list_output_validator_list = [
            HasFieldsOfValidator()
        ]
        list_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/policy/api/v1/infra/tier-1s/{tier-1-id}/locale-services/{locale-service-id}/ipsec-vpn-services/{service-id}/local-endpoints',
            path_variables={
                'tier1_id': 'tier-1-id',
                'locale_service_id': 'locale-service-id',
                'service_id': 'service-id',
            },
             header_parameters={
                               },
            query_parameters={
                'cursor': 'cursor',
                'include_mark_for_delete_objects': 'include_mark_for_delete_objects',
                'included_fields': 'included_fields',
                'page_size': 'page_size',
                'sort_ascending': 'sort_ascending',
                'sort_by': 'sort_by',
            },
            content_type='application/json'
        )

        # properties for patch operation
        patch_input_type = type.StructType('operation-input', {
            'tier1_id': type.StringType(),
            'locale_service_id': type.StringType(),
            'service_id': type.StringType(),
            'local_endpoint_id': type.StringType(),
            'ip_sec_vpn_local_endpoint': type.ReferenceType('com.vmware.nsx_policy.model_client', 'IPSecVpnLocalEndpoint'),
        })
        patch_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        patch_input_value_validator_list = [
            HasFieldsOfValidator()
        ]
        patch_output_validator_list = [
        ]
        patch_rest_metadata = OperationRestMetadata(
            http_method='PATCH',
            url_template='/policy/api/v1/infra/tier-1s/{tier-1-id}/locale-services/{locale-service-id}/ipsec-vpn-services/{service-id}/local-endpoints/{local-endpoint-id}',
            request_body_parameter='ip_sec_vpn_local_endpoint',
            path_variables={
                'tier1_id': 'tier-1-id',
                'locale_service_id': 'locale-service-id',
                'service_id': 'service-id',
                'local_endpoint_id': 'local-endpoint-id',
            },
             header_parameters={
                       },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for update operation
        update_input_type = type.StructType('operation-input', {
            'tier1_id': type.StringType(),
            'locale_service_id': type.StringType(),
            'service_id': type.StringType(),
            'local_endpoint_id': type.StringType(),
            'ip_sec_vpn_local_endpoint': type.ReferenceType('com.vmware.nsx_policy.model_client', 'IPSecVpnLocalEndpoint'),
        })
        update_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        update_input_value_validator_list = [
            HasFieldsOfValidator()
        ]
        update_output_validator_list = [
            HasFieldsOfValidator()
        ]
        update_rest_metadata = OperationRestMetadata(
            http_method='PUT',
            url_template='/policy/api/v1/infra/tier-1s/{tier-1-id}/locale-services/{locale-service-id}/ipsec-vpn-services/{service-id}/local-endpoints/{local-endpoint-id}',
            request_body_parameter='ip_sec_vpn_local_endpoint',
            path_variables={
                'tier1_id': 'tier-1-id',
                'locale_service_id': 'locale-service-id',
                'service_id': 'service-id',
                'local_endpoint_id': 'local-endpoint-id',
            },
             header_parameters={
                       },
            query_parameters={
            },
            content_type='application/json'
        )

        operations = {
            'delete': {
                'input_type': delete_input_type,
                'output_type': type.VoidType(),
                'errors': delete_error_dict,
                'input_value_validator_list': delete_input_value_validator_list,
                'output_validator_list': delete_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'get': {
                'input_type': get_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx_policy.model_client', 'IPSecVpnLocalEndpoint'),
                'errors': get_error_dict,
                'input_value_validator_list': get_input_value_validator_list,
                'output_validator_list': get_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'list': {
                'input_type': list_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx_policy.model_client', 'IPSecVpnLocalEndpointListResult'),
                'errors': list_error_dict,
                'input_value_validator_list': list_input_value_validator_list,
                'output_validator_list': list_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'patch': {
                'input_type': patch_input_type,
                'output_type': type.VoidType(),
                'errors': patch_error_dict,
                'input_value_validator_list': patch_input_value_validator_list,
                'output_validator_list': patch_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'update': {
                'input_type': update_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx_policy.model_client', 'IPSecVpnLocalEndpoint'),
                'errors': update_error_dict,
                'input_value_validator_list': update_input_value_validator_list,
                'output_validator_list': update_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        rest_metadata = {
            'delete': delete_rest_metadata,
            'get': get_rest_metadata,
            'list': list_rest_metadata,
            'patch': patch_rest_metadata,
            'update': update_rest_metadata,
        }
        ApiInterfaceStub.__init__(
            self, iface_name='com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.local_endpoints',
            config=config, operations=operations, rest_metadata=rest_metadata,
            is_vapi_rest=False)

class _SessionsStub(ApiInterfaceStub):
    def __init__(self, config):
        # properties for delete operation
        delete_input_type = type.StructType('operation-input', {
            'tier1_id': type.StringType(),
            'locale_service_id': type.StringType(),
            'service_id': type.StringType(),
            'session_id': type.StringType(),
        })
        delete_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        delete_input_value_validator_list = [
        ]
        delete_output_validator_list = [
        ]
        delete_rest_metadata = OperationRestMetadata(
            http_method='DELETE',
            url_template='/policy/api/v1/infra/tier-1s/{tier-1-id}/locale-services/{locale-service-id}/ipsec-vpn-services/{service-id}/sessions/{session-id}',
            path_variables={
                'tier1_id': 'tier-1-id',
                'locale_service_id': 'locale-service-id',
                'service_id': 'service-id',
                'session_id': 'session-id',
            },
             header_parameters={
                     },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for get operation
        get_input_type = type.StructType('operation-input', {
            'tier1_id': type.StringType(),
            'locale_service_id': type.StringType(),
            'service_id': type.StringType(),
            'session_id': type.StringType(),
        })
        get_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        get_input_value_validator_list = [
        ]
        get_output_validator_list = [
            HasFieldsOfValidator()
        ]
        get_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/policy/api/v1/infra/tier-1s/{tier-1-id}/locale-services/{locale-service-id}/ipsec-vpn-services/{service-id}/sessions/{session-id}',
            path_variables={
                'tier1_id': 'tier-1-id',
                'locale_service_id': 'locale-service-id',
                'service_id': 'service-id',
                'session_id': 'session-id',
            },
             header_parameters={
                     },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for list operation
        list_input_type = type.StructType('operation-input', {
            'tier1_id': type.StringType(),
            'locale_service_id': type.StringType(),
            'service_id': type.StringType(),
            'cursor': type.OptionalType(type.StringType()),
            'include_mark_for_delete_objects': type.OptionalType(type.BooleanType()),
            'included_fields': type.OptionalType(type.StringType()),
            'page_size': type.OptionalType(type.IntegerType()),
            'sort_ascending': type.OptionalType(type.BooleanType()),
            'sort_by': type.OptionalType(type.StringType()),
        })
        list_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        list_input_value_validator_list = [
        ]
        list_output_validator_list = [
            HasFieldsOfValidator()
        ]
        list_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/policy/api/v1/infra/tier-1s/{tier-1-id}/locale-services/{locale-service-id}/ipsec-vpn-services/{service-id}/sessions',
            path_variables={
                'tier1_id': 'tier-1-id',
                'locale_service_id': 'locale-service-id',
                'service_id': 'service-id',
            },
             header_parameters={
                               },
            query_parameters={
                'cursor': 'cursor',
                'include_mark_for_delete_objects': 'include_mark_for_delete_objects',
                'included_fields': 'included_fields',
                'page_size': 'page_size',
                'sort_ascending': 'sort_ascending',
                'sort_by': 'sort_by',
            },
            content_type='application/json'
        )

        # properties for patch operation
        patch_input_type = type.StructType('operation-input', {
            'tier1_id': type.StringType(),
            'locale_service_id': type.StringType(),
            'service_id': type.StringType(),
            'session_id': type.StringType(),
            'ip_sec_vpn_session': type.DynamicStructType('vmware.vapi.dynamic_struct', {}, VapiStruct, [type.ReferenceType('com.vmware.nsx_policy.model_client', 'IPSecVpnSession')]),
        })
        patch_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        patch_input_value_validator_list = [
            HasFieldsOfValidator()
        ]
        patch_output_validator_list = [
        ]
        patch_rest_metadata = OperationRestMetadata(
            http_method='PATCH',
            url_template='/policy/api/v1/infra/tier-1s/{tier-1-id}/locale-services/{locale-service-id}/ipsec-vpn-services/{service-id}/sessions/{session-id}',
            request_body_parameter='ip_sec_vpn_session',
            path_variables={
                'tier1_id': 'tier-1-id',
                'locale_service_id': 'locale-service-id',
                'service_id': 'service-id',
                'session_id': 'session-id',
            },
             header_parameters={
                       },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for showsensitivedata operation
        showsensitivedata_input_type = type.StructType('operation-input', {
            'tier1_id': type.StringType(),
            'locale_service_id': type.StringType(),
            'service_id': type.StringType(),
            'session_id': type.StringType(),
        })
        showsensitivedata_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        showsensitivedata_input_value_validator_list = [
        ]
        showsensitivedata_output_validator_list = [
            HasFieldsOfValidator()
        ]
        showsensitivedata_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/policy/api/v1/infra/tier-1s/{tier-1-id}/locale-services/{locale-service-id}/ipsec-vpn-services/{service-id}/sessions/{session-id}?action=show_sensitive_data',
            path_variables={
                'tier1_id': 'tier-1-id',
                'locale_service_id': 'locale-service-id',
                'service_id': 'service-id',
                'session_id': 'session-id',
            },
             header_parameters={
                     },
            query_parameters={
            },
            content_type='application/json'
        )

        # properties for update operation
        update_input_type = type.StructType('operation-input', {
            'tier1_id': type.StringType(),
            'locale_service_id': type.StringType(),
            'service_id': type.StringType(),
            'session_id': type.StringType(),
            'ip_sec_vpn_session': type.DynamicStructType('vmware.vapi.dynamic_struct', {}, VapiStruct, [type.ReferenceType('com.vmware.nsx_policy.model_client', 'IPSecVpnSession')]),
        })
        update_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        update_input_value_validator_list = [
            HasFieldsOfValidator()
        ]
        update_output_validator_list = [
            HasFieldsOfValidator()
        ]
        update_rest_metadata = OperationRestMetadata(
            http_method='PUT',
            url_template='/policy/api/v1/infra/tier-1s/{tier-1-id}/locale-services/{locale-service-id}/ipsec-vpn-services/{service-id}/sessions/{session-id}',
            request_body_parameter='ip_sec_vpn_session',
            path_variables={
                'tier1_id': 'tier-1-id',
                'locale_service_id': 'locale-service-id',
                'service_id': 'service-id',
                'session_id': 'session-id',
            },
             header_parameters={
                       },
            query_parameters={
            },
            content_type='application/json'
        )

        operations = {
            'delete': {
                'input_type': delete_input_type,
                'output_type': type.VoidType(),
                'errors': delete_error_dict,
                'input_value_validator_list': delete_input_value_validator_list,
                'output_validator_list': delete_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'get': {
                'input_type': get_input_type,
                'output_type': type.DynamicStructType('vmware.vapi.dynamic_struct', {}, VapiStruct, [type.ReferenceType('com.vmware.nsx_policy.model_client', 'IPSecVpnSession')]),
                'errors': get_error_dict,
                'input_value_validator_list': get_input_value_validator_list,
                'output_validator_list': get_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'list': {
                'input_type': list_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx_policy.model_client', 'IPSecVpnSessionListResult'),
                'errors': list_error_dict,
                'input_value_validator_list': list_input_value_validator_list,
                'output_validator_list': list_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'patch': {
                'input_type': patch_input_type,
                'output_type': type.VoidType(),
                'errors': patch_error_dict,
                'input_value_validator_list': patch_input_value_validator_list,
                'output_validator_list': patch_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'showsensitivedata': {
                'input_type': showsensitivedata_input_type,
                'output_type': type.DynamicStructType('vmware.vapi.dynamic_struct', {}, VapiStruct, [type.ReferenceType('com.vmware.nsx_policy.model_client', 'IPSecVpnSession')]),
                'errors': showsensitivedata_error_dict,
                'input_value_validator_list': showsensitivedata_input_value_validator_list,
                'output_validator_list': showsensitivedata_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'update': {
                'input_type': update_input_type,
                'output_type': type.DynamicStructType('vmware.vapi.dynamic_struct', {}, VapiStruct, [type.ReferenceType('com.vmware.nsx_policy.model_client', 'IPSecVpnSession')]),
                'errors': update_error_dict,
                'input_value_validator_list': update_input_value_validator_list,
                'output_validator_list': update_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        rest_metadata = {
            'delete': delete_rest_metadata,
            'get': get_rest_metadata,
            'list': list_rest_metadata,
            'patch': patch_rest_metadata,
            'showsensitivedata': showsensitivedata_rest_metadata,
            'update': update_rest_metadata,
        }
        ApiInterfaceStub.__init__(
            self, iface_name='com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.sessions',
            config=config, operations=operations, rest_metadata=rest_metadata,
            is_vapi_rest=False)

class _SummaryStub(ApiInterfaceStub):
    def __init__(self, config):
        # properties for get operation
        get_input_type = type.StructType('operation-input', {
            'tier1_id': type.StringType(),
            'locale_service_id': type.StringType(),
            'service_id': type.StringType(),
            'enforcement_point_path': type.OptionalType(type.StringType()),
            'source': type.OptionalType(type.StringType()),
        })
        get_error_dict = {
            'com.vmware.vapi.std.errors.invalid_request':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidRequest'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.service_unavailable':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ServiceUnavailable'),
            'com.vmware.vapi.std.errors.internal_server_error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InternalServerError'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),

        }
        get_input_value_validator_list = [
        ]
        get_output_validator_list = [
        ]
        get_rest_metadata = OperationRestMetadata(
            http_method='GET',
            url_template='/policy/api/v1/infra/tier-1s/{tier-1-id}/locale-services/{locale-service-id}/ipsec-vpn-services/{service-id}/summary',
            path_variables={
                'tier1_id': 'tier-1-id',
                'locale_service_id': 'locale-service-id',
                'service_id': 'service-id',
            },
             header_parameters={
                       },
            query_parameters={
                'enforcement_point_path': 'enforcement_point_path',
                'source': 'source',
            },
            content_type='application/json'
        )

        operations = {
            'get': {
                'input_type': get_input_type,
                'output_type': type.ReferenceType('com.vmware.nsx_policy.model_client', 'PolicyIpsecVpnIkeServiceSummary'),
                'errors': get_error_dict,
                'input_value_validator_list': get_input_value_validator_list,
                'output_validator_list': get_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        rest_metadata = {
            'get': get_rest_metadata,
        }
        ApiInterfaceStub.__init__(
            self, iface_name='com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.summary',
            config=config, operations=operations, rest_metadata=rest_metadata,
            is_vapi_rest=False)


class StubFactory(StubFactoryBase):
    _attrs = {
        'LocalEndpoints': LocalEndpoints,
        'Sessions': Sessions,
        'Summary': Summary,
        'sessions': 'com.vmware.nsx_policy.infra.tier_1s.locale_services.ipsec_vpn_services.sessions_client.StubFactory',
    }

