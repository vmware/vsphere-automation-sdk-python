#!/usr/bin/env python

"""
Section names used in vAPI properties file
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2015-2017 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long

ENDPOINT = 'endpoint'
JSONRPC = 'jsonrpc'
LOGGERS = 'loggers'
LOGGING = 'logging'
REST = 'rest'
SSL = 'ssl'
